// MyList7.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SecurityGuard.h"
#include "MyList7.h"


// CMyList7

IMPLEMENT_DYNAMIC(CMyList7, CListCtrl)

CMyList7::CMyList7()
{

}

CMyList7::~CMyList7()
{
}


BEGIN_MESSAGE_MAP(CMyList7, CListCtrl)
END_MESSAGE_MAP()



// CMyList7 ��Ϣ��������


