#pragma once


// MCBUTTON_CC

class MCBUTTON_CC : public CButton
{
	DECLARE_DYNAMIC(MCBUTTON_CC)

public:
	MCBUTTON_CC();
	virtual ~MCBUTTON_CC();

protected:
	DECLARE_MESSAGE_MAP()
private:
	enum BUTTONSTATE{ NORMAL, MOUSEOVER, BUTTONDOWN };
	BUTTONSTATE m_btnState;					//��ť״̬
	bool m_bIsButtonDown;
	bool m_bIsMouseHower;
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT /*lpDrawItemStruct*/);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnMouseHover(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
};


