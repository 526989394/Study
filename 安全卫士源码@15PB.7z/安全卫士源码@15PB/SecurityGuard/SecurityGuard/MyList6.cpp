// MyList6.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SecurityGuard.h"
#include "MyList6.h"


// CMyList6

IMPLEMENT_DYNAMIC(CMyList6, CListCtrl)

CMyList6::CMyList6()
{

}

CMyList6::~CMyList6()
{
}


BEGIN_MESSAGE_MAP(CMyList6, CListCtrl)
END_MESSAGE_MAP()



// CMyList6 ��Ϣ��������


