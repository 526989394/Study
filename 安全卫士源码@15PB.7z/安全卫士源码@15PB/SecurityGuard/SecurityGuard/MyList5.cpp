// MyList5.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SecurityGuard.h"
#include "MyList5.h"


// CMyList5

IMPLEMENT_DYNAMIC(CMyList5, CListCtrl)

CMyList5::CMyList5()
{

}

CMyList5::~CMyList5()
{
}


BEGIN_MESSAGE_MAP(CMyList5, CListCtrl)
END_MESSAGE_MAP()



// CMyList5 ��Ϣ��������


