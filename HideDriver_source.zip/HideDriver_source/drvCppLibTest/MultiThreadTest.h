#pragma once

void MultiThreadTest(size_t threadCount);