/*
    Test driver for a C++ run-time library that supports C++ exception
    handling and run-time type information.
    Copyright (C) 2003, 2004 Bo Branten.
*/

extern "C" {
#define POINTER_64
#include <ntddk.h>
}
#include "libcpp.h"
#include "typeinfo.h"

#include "CppLibTest.h"

class ClassA{virtual void f(){}};
class ClassAA : public ClassA{};
class ClassB{};

class Object {
public:
    Object(char* s) : m_name(s)                 { DbgPrint("Object %s was constructed\n", m_name); }
    Object(const Object& o) : m_name(o.m_name)  { DbgPrint("Object %s was copied\n", m_name); }
    ~Object()                                   { DbgPrint("Object %s was deleted\n", m_name); }
    char* GetName()                             { return m_name; }
private:
    char* m_name;
};

Object g("global");

void CppLibTest()
{
    //
    // Test run-time type information.
    //

    DbgPrint("Test run-time type information\n");

    const type_info& gt = typeid(g);

    DbgPrint("The name of the global object g is: %s\n", gt.name());

    
    ClassA a1, a2;
    ClassAA aa;
    ClassB b;

    void* pv = dynamic_cast<void*>(&a1);

    ClassA* ap = &aa;
    ClassAA* aap = dynamic_cast<ClassAA*>(ap);

    DbgPrint("The type name of the object ap points to is: %s\n", typeid(*ap).name());

    if (typeid(a1) == typeid(a2))
    {
        DbgPrint("%s and %s is of the same type\n", typeid(a1).name(), typeid(a2).name());
    }

    if (typeid(a1) != typeid(b))
    {
        DbgPrint("%s and %s is not of the same type\n", typeid(a1).name(), typeid(b).name());
    }

    DbgPrint("\n");

    //
    // Test exception handling.
    //
    DbgPrint("Test exception handling.\n");

    try {
        Object l1("local 1");
        DbgPrint("Throwing an exception\n");
        throw Object("an exception");
    }
    catch (Object& e) {
        DbgPrint("Catching %s\n", e.GetName());
    }

    DbgPrint("\n");

    //
    // Test re-throwing an exception.
    //
    DbgPrint("Test re-throwing an exception.\n");

    try {
        Object l3("local 3");
        try {
            Object l4("local 4");
            DbgPrint("Throwing an exception to re-throw\n");
            throw Object("an exception to re-throw");
        }
        catch (Object& e) {
            DbgPrint("Catching %s the first time\n", e.GetName());
            throw;
        }
    }
    catch (Object& e) {
        DbgPrint("Catching %s the second time\n", e.GetName());
    }

    DbgPrint("\n");

    //
    // Test exception handling at DISPATCH_LEVEL.
    //
    DbgPrint("Test exception handling at DISPATCH_LEVEL.\n");
    

    KIRQL SavedIrql;

    DbgPrint("Raising IRQL to DISPATCH_LEVEL\n");

    KeRaiseIrql(DISPATCH_LEVEL, &SavedIrql);

    try {
        Object l5("local 5");
        DbgPrint("Throwing an exception at DISPATCH_LEVEL\n");
        throw Object("an exception at DISPATCH_LEVEL");
    }
    catch (Object& e) {
        DbgPrint("Catching %s\n", e.GetName());
    }

    DbgPrint("Lower IRQL from DISPATCH_LEVEL\n");

    KeLowerIrql(SavedIrql);

    DbgPrint("\n");
}