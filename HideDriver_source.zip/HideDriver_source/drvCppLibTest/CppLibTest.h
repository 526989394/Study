#pragma once

void CppLibTest();