extern "C" {
#define POINTER_64
#include <ntddk.h>
}
#include "libcpp.h"
#include "CppLibTest.h"
#include "MultiThreadTest.h"

extern "C"
NTSTATUS
DriverEntry(
    IN PDRIVER_OBJECT   DriverObject,
    IN PUNICODE_STRING  RegistryPath
    )
{
    libcpp_init();

    DbgPrint("-CppLibTest- Entering the driver\n");

    CppLibTest();
    MultiThreadTest(20);

    DbgPrint("-CppLibTest- Exiting the driver\n");

    libcpp_exit();

    return STATUS_UNSUCCESSFUL; // don't load the driver.
}