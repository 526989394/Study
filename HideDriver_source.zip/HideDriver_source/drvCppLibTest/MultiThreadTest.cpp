extern "C" {
#define POINTER_64
#include <ntddk.h>
}
#include <exception>
#include "MultiThreadTest.h"

typedef void *HANDLE;
typedef HANDLE *PHANDLE;

void ThreadFunc( void* pArguments );

void MultiThreadTest(size_t threadCount)
{
    DbgPrint("MultiThreadTest running\n");

    size_t hub = 0;
    for(int i=0;i<threadCount;++i)
    {
        HANDLE hThread = NULL;
        NTSTATUS status = PsCreateSystemThread(&hThread,
                                                THREAD_ALL_ACCESS,
                                                NULL,
                                                NULL,
                                                NULL,
                                                &ThreadFunc,
                                                &hub);
        if( status != STATUS_SUCCESS)
        {
            DbgPrint("PsCreateSystemThread fail.\n");
            return;
        }
        ZwClose(hThread);
    }

    KEVENT event_;
    KeInitializeEvent(&event_, NotificationEvent, FALSE);

    while(true)
    {
        if(hub == threadCount)
            return;

        LARGE_INTEGER timout;
        size_t twoSecond =  2000*10;// one wait unit - 100 nanoseconds
        timout.QuadPart = (__int64)-1*twoSecond; // negative value specifies an interval relative to the current time
        KeWaitForSingleObject(&event_, Executive, KernelMode, FALSE, &timout);
    }
}

class Local
{
    char member[256];
public:
    Local()
    {}
};
void ThrowAndReThrow()
{
    try 
    {
        Local localClass;
        try 
        {
            Local localClass2;
            throw std::exception("an exception to re-throw");
        }
        catch (const std::exception& e) 
        {
            throw;
        }
    }
    catch (const std::exception& ex) 
    {}
}
void ThrowEx()
{
    Local localClass;
    throw std::exception("Informative text");
}
void Throw()
{
    Local localClass;
    ThrowEx();
}
void ThrowAndCatch()
{
    try
    {
        Throw();
        ThrowAndReThrow();
    }
    catch(const std::exception ex)
    {}
}
void ThreadFunc( void* pArguments )
{
    size_t* hub = (size_t*)pArguments;
    for(size_t i = 0 ; i<100; ++i )
    {
        DbgPrint(".");
        ThrowAndCatch();
    }
    DbgPrint("\n");

    InterlockedIncrement((PLONG)hub);

    PsTerminateSystemThread( 0 );
}