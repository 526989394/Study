#include "DPCTest.h"

const long STOP  = 0;
const long START = 1;
const long STARTED = 2;
void DPCTest::Run()
{ 
	mSingleMode.Mode = Mode;

	PKTHREAD myThread;
	NTSTATUS ret_status= NULL;

	DbgPrint("DPCTest running\n");

	// Starting system thread
	mHub = START;
	ret_status = PsCreateSystemThread(&hThread,THREAD_ALL_ACCESS,NULL,NULL,NULL,&gThreadFunc,this);
	if(ret_status != STATUS_SUCCESS)
	{
		DbgPrint("DPCTest error PsCreateSystemThread\n");
		mHub = STOP;
		return;
	}
	// Wait until thread a started
	while(mHub == STARTED);

	// Entering single mode and run test.
	ExSetHook<DPCTest>(*this,&DPCTest::ThreadFunc);


	// Stopping system thread 
	mHub = STOP;
	ret_status = ObReferenceObjectByHandle(&hThread,THREAD_ALL_ACCESS,NULL,
		KernelMode,(PVOID*)(&myThread),NULL);

	if(ret_status == STATUS_SUCCESS)
	{
		KeWaitForSingleObject(&myThread,Executive ,KernelMode ,FALSE,NULL);
		ObDereferenceObject(myThread);
	}

	DbgPrint("mCallCount: %d\n",mCallCount);

	ZwClose(hThread);
}

void gThreadFunc( void* pArguments )
{
	DPCTest* pThis = (DPCTest*)pArguments;

	volatile long& refHub = pThis->mHub;
	volatile long& refCallCount = pThis->mCallCount;
	volatile long& refStartToCount = pThis->mStartToCount;
	
	refHub = STARTED;
	do 
	{
		if(refStartToCount == START)
			++refCallCount;
	} 
	while(refHub != STOP);

	PsTerminateSystemThread( 0 );
}
void DPCTest::ThreadFunc()
{
	// Signaling to other thread start count
	mStartToCount = START;

	// Wait some time
	for(size_t i=0;i<ClockNumber;++i);
	
	// Signaling to other thread stop count
	mStartToCount = STOP;
}