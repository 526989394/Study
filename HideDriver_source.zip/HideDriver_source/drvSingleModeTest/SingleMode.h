#if !defined(AFX_SINGLEMODE_H__3550FF5A_AFA0_402B_932B_8C1183F6A222__INCLUDED_)
#define AFX_SINGLEMODE_H__3550FF5A_AFA0_402B_932B_8C1183F6A222__INCLUDED_

#include "common.h"
const long ModeOneProc = 0;
const long ModeMultiProc = 1;
class SingleProcessorMode
{
	KDPC *DpcArray;
	
	volatile LONG mHub;
	CCHAR mCpuCount;
	KIRQL mSavedIrql;
	KPRIORITY mSavedPriority;
	static void DpcRoutine(KDPC *pDpc, void *pContext, void *pArg1, void *pArg2);
	static void ProcessorPause();


public:
	long Mode;
	SingleProcessorMode();
	void Enter();
	void Exit();
};

#endif // !defined(AFX_SINGLEMODE_H__3550FF5A_AFA0_402B_932B_8C1183F6A222__INCLUDED_)