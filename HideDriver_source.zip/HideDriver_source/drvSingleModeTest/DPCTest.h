#if !defined(AFX_DPCTEST_H__9CEEA652_B73A_4F3D_902C_D271D7C28AC7__INCLUDED_)
#define AFX_DPCTEST_H__9CEEA652_B73A_4F3D_902C_D271D7C28AC7__INCLUDED_

#include "common.h"
#include "HookMng.h"


class DPCTest:public HookMng
{
private:
	HANDLE hThread;
public:
	DPCTest():mHub(0),mCallCount(0),mStartToCount(0),ClockNumber(0){}
	volatile long mHub;
	volatile long mCallCount;
	volatile long mStartToCount;
	long ClockNumber;
	long Mode;
	void ThreadFunc();
	void Run();
};

void gThreadFunc( void* pArguments );

#endif // !defined(AFX_DPCTEST_H__9CEEA652_B73A_4F3D_902C_D271D7C28AC7__INCLUDED_)