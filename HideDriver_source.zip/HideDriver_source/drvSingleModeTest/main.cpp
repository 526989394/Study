#include "common.h"
#include "DPCTest.h"
#include "..\HideDriver\Ioctl.h"
///////////////////////////////////////////////////////////////////////////////////////////////

UNICODE_STRING DeviceName;
UNICODE_STRING SymbolicLinkName;

PDEVICE_OBJECT deviceObject = NULL;

///////////////////////////////////////////////////////////////////////////////////////////////


extern "C"
{
	NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,IN PUNICODE_STRING RegistryPath);
	VOID DriverUnload(IN PDRIVER_OBJECT DriverObject);
	NTSTATUS CompleteIrp( PIRP Irp, NTSTATUS status, ULONG info);
	NTSTATUS DeviceControlRoutine( IN PDEVICE_OBJECT fdo, IN PIRP Irp );
	NTSTATUS Close_HandleIRPprocessing(IN PDEVICE_OBJECT fdo,IN PIRP Irp);
	NTSTATUS Create_File_IRPprocessing(IN PDEVICE_OBJECT fdo,IN PIRP Irp);
}// extern "C"

NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,
                     IN PUNICODE_STRING RegistryPath)
{
	PDRIVER_DISPATCH *mj_func;
	NTSTATUS st;
	PCWSTR dDeviceName       = L"\\Device\\TestDriver";
    PCWSTR dSymbolicLinkName = L"\\DosDevices\\TestDriver";
	libcpp_init();	

	DbgPrint("\t------TEST DRIVER START------\n");


    RtlInitUnicodeString(&DeviceName,       dDeviceName);
    RtlInitUnicodeString(&SymbolicLinkName, dSymbolicLinkName);

    st = IoCreateDevice(DriverObject,    // pointer on DriverObject
		                0,               // additional size of memory, for dev. extension
		                &DeviceName,     // pointer to UNICODE_STRING
                        FILE_DEVICE_NULL,// Device type
						0,               // Device characteristic
                        FALSE,           // "Exclusive" device
						&deviceObject);  // pointer do device object


    if (st == STATUS_SUCCESS)
      st = IoCreateSymbolicLink(&SymbolicLinkName,
	                            &DeviceName);      

	mj_func = DriverObject->MajorFunction;
	DriverObject->DriverUnload = DriverUnload;
	
	mj_func[IRP_MJ_DEVICE_CONTROL] = DeviceControlRoutine;
	mj_func[IRP_MJ_CREATE] = Create_File_IRPprocessing;
	mj_func[IRP_MJ_CLOSE]  = Close_HandleIRPprocessing;
	

	return STATUS_SUCCESS;
}

VOID DriverUnload(IN PDRIVER_OBJECT DriverObject)
{	
	IoDeleteSymbolicLink(&SymbolicLinkName);
	IoDeleteDevice(deviceObject);


	// Cpp unload
	libcpp_exit();

	DbgPrint("\t------TEST DRIVER EXIT------\n");
	
	return;
}
NTSTATUS CompleteIrp( PIRP Irp, NTSTATUS status, ULONG info)
{
	Irp->IoStatus.Status = status;
	Irp->IoStatus.Information = info;
	IoCompleteRequest(Irp,IO_NO_INCREMENT);
	return status;
}
NTSTATUS DriverTest(WCHAR* pBuf,ULONG buf_size,ULONG out_buf_size,PULONG BytesTxd)
{
	DbgPrint("-TestDriver- IOCTL_DRIVER_TEST\n");
	if(out_buf_size< 4 || buf_size <8)
		return STATUS_BUFFER_TOO_SMALL;

	LONG ClockCount;
	memcpy(&ClockCount,pBuf,4);
	LONG Mode;
	memcpy(&Mode,(char*)pBuf+4,4);

	DPCTest dpcT;
	dpcT.ClockNumber = ClockCount;
	dpcT.Mode = Mode;
	dpcT.Run();

	memcpy(pBuf,(void*)&dpcT.mCallCount,4);
	*BytesTxd = 4;

	return STATUS_SUCCESS;
}
NTSTATUS DeviceControlRoutine( IN PDEVICE_OBJECT fdo, IN PIRP pIrp )
/*++

Routine Description:



Arguments:



Return Value:



--*/
{
	NTSTATUS status = STATUS_SUCCESS;
	ULONG BytesTxd =0; // Number of transmitted,received bytes
	PIO_STACK_LOCATION IrpStack=IoGetCurrentIrpStackLocation(pIrp);

	// Getting the IOCTL code
	ULONG ControlCode =
		IrpStack->Parameters.DeviceIoControl.IoControlCode;
	// Getting the exchange method
	//selection of the first two bits
	ULONG method = ControlCode & 0x03;

	if(method!=METHOD_BUFFERED)
		return CompleteIrp(pIrp,STATUS_INVALID_PARAMETER,BytesTxd); 

	ULONG InputLength = 
		IrpStack->Parameters.DeviceIoControl.InputBufferLength;

	ULONG OutputLength =
		IrpStack->Parameters.DeviceIoControl.OutputBufferLength;

	if( OutputLength < 1 || InputLength < 1)
		return CompleteIrp(pIrp,STATUS_INVALID_PARAMETER,BytesTxd);

	WCHAR *buff;
	buff = (PWCHAR)pIrp->AssociatedIrp.SystemBuffer;

	switch( ControlCode) 
	{
	case IOCTL_DRIVER_TEST:
		status = DriverTest(buff,InputLength,OutputLength,&BytesTxd); break;
	default:	
		status = STATUS_INVALID_DEVICE_REQUEST;
	}
	return CompleteIrp(pIrp,status,BytesTxd); 
}
// Create_File_IRPprocessing: process IRP_MJ_CREATE query.
NTSTATUS Create_File_IRPprocessing(IN PDEVICE_OBJECT fdo,IN PIRP Irp)
{
	DbgPrint("-TestDriver- IRP_MJ_CREATE\n");

	return CompleteIrp(Irp,STATUS_SUCCESS,0);
}

// Close_File_IRPprocessing: process IRP_MJ_CLOSE query.
NTSTATUS Close_HandleIRPprocessing(IN PDEVICE_OBJECT fdo,IN PIRP Irp)
{
	DbgPrint("-TestDriver- IRP_MJ_CLOSE\n");

	return CompleteIrp(Irp,STATUS_SUCCESS,0);
}