#pragma once

namespace utils
{
class DriverWork
{
public:
    static void Install(LPCTSTR DriverName,LPCTSTR driverExec,DWORD startType);
    static void Remove(LPCTSTR DriverName,LPCTSTR driverExec);
    static void Start(LPCTSTR DriverName);
    static void Stop(LPCTSTR DriverName);
    static void Exchange(LPCTSTR DriverName, 
                         unsigned long ioctlCode,
                         PWCHAR pInStr,
                         DWORD inStr_size,
                         PWCHAR pOutStr,
                         DWORD outStr_size,
                         PDWORD BytesReturned);
};
}// namespace utils