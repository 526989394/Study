#pragma once

#include "HandleGuardImpl.h"

#include "Lm.h" // for NetApiBufferFree()
#include "Tlhelp32.h" // for CloseToolhelp32Snapshot

namespace utils
{

class CloseHandleAction
{
public:
    static void Execute(HANDLE handle)
    {
        CloseHandle(handle);
    }
};
typedef HandleGuardImpl<HANDLE,CloseHandleAction> HandleGuard;

class ServiceCloseHandleAction
{
public:
    static void Execute(SC_HANDLE scHandle_)
    {
        CloseServiceHandle(scHandle_);
    }
};
typedef HandleGuardImpl<SC_HANDLE,ServiceCloseHandleAction> ServiceHandleGuard;

class LocalCloseHandleAction
{
public:
    static void Execute(HLOCAL hLocal)
    {
        LocalFree(hLocal);
    }
};
typedef HandleGuardImpl<HLOCAL,LocalCloseHandleAction> LocalHandleGuard;

class LibCloseHandleAction
{
public:
    static void Execute(HMODULE hLib)
    {
        FreeLibrary(hLib);
    }
};
typedef HandleGuardImpl<HMODULE,LibCloseHandleAction> LibHandleGuard;

class NetCloseHandleAction
{
public:
    static void Execute(PVOID pointer)
    {
        NetApiBufferFree(pointer);
    }
};
typedef HandleGuardImpl<PVOID,NetCloseHandleAction> NetHandleGuard;


}//namespace utils