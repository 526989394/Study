#pragma once
#include "HandleGuard.h"
#include <string>

namespace utils
{
inline std::string GetWinErrorText(DWORD dwError)
{
    HLOCAL hlocal = NULL;   // Buffer that gets the error message string

    // Get the error code's textual description
    DWORD strSize = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER,
                                   NULL, 
                                   dwError,
                                   0, // Default language
                                   (LPSTR) &hlocal, 
                                   0, 
                                   NULL);
    if (strSize != NULL)
    {
        LocalHandleGuard guard(hlocal);

        std::string str;
        str += (const char*) LocalLock(hlocal);
        return str;
    }

    // Is it a network-related error?
    HMODULE hDll = LoadLibraryEx(TEXT("netmsg.dll"), 
                                 NULL,
                                 DONT_RESOLVE_DLL_REFERENCES);
    if (hDll == INVALID_HANDLE_VALUE) 
        return std::string("Can't load netmsg.dll");

    LibHandleGuard guard(hDll);

    strSize = FormatMessageA(FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_FROM_SYSTEM,
                             hDll, 
                             dwError, 
                             0,// Default language
                             (LPSTR) &hlocal, 
                             0, 
                             NULL);
    if (strSize != NULL)
    {
        LocalHandleGuard guard(hlocal);

        std::string str;
        str += (const char*)LocalLock(hlocal);
        return str;
    }

    return std::string("Unknown error.");
}
inline std::string GetLastErrorStr()
{
    return GetWinErrorText(GetLastError());
}
}