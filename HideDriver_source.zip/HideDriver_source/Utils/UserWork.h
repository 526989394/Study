#pragma once
#include <windows.h>
#include "AutoArray.h"
#include <string>
#include <list>

namespace utils
{
typedef std::pair<std::wstring,std::wstring> UserNameSidPair;
typedef std::list<UserNameSidPair> UserNameSidList;

void GetUserNames(UserNameSidList* userList);

void GetSidByName(const std::wstring& userName,auto_array<BYTE>* sid);

void GetNameBySid(const auto_array<BYTE>& sid,std::wstring* userName);

}//namespace utils