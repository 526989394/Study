#ifndef HIDE_DRIVER_IOCTL_H_INCLUDED
#define HIDE_DRIVER_IOCTL_H_INCLUDED

/* This file defines Input-Output Control Codes to communicate with HideDriver. */

/*
All input strings(parameters) is UNICODE strings.
If error occur driver return ASCII string with error description.
*/

/*
Almost all IOCTLs work with hide rules.
   Hide rule support following options: 
   - Hide from list of process, this mean that only selected process
     mustn't see this process or file
   - Hide from list of users, this mean only selected users
     mustn't see this process or file
   *This options can be used together

Format of hide rule string must be: 
    process(file)_name_to_hide;access_user_name;access_process_name
    
Where: 
    process(file)_name_to_hide - process name(file path) to hide.
    access_user_name           - user's name, which mustn't see this process(file).
    access_process_name        - process's name, which mustn't see this process(file).

To insert several process or users that mustn't see this process separate it by ',' character.
Example:
    process_name_to_hide;user_name1,user_name2;process_name1,process_name2

All names support following masks:
"*" - Matches all characters
"?" - Matches any single character

Final examples:
    *;*;*        - Hide all process from all users and process. Just for fun.
    System;*;*   - Hide process system from all users and process.
    er*;*;*      - Hide all process wich name starts with "er" characters.
    System;*;Rob - Hide process "System" for User: Rob
*/


/*-----------------------------------------------------------------------*/
/*                            Process hide IOCTLs                        */

#define IOCTL_ADD_PROCESS_HIDE_RULE CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)

/*
This IOCTL used to add process hide rule to hide list.

Input string must be hide rule.
*/

#define IOCTL_DEL_PROCESS_HIDE_RULE CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)

/*
This IOCTL used to delete process hide rule from hide list.

Input string must be hide rule.
*/

#define IOCTL_CLEAR_PROCESS_HIDE_RULES CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x803, METHOD_BUFFERED, FILE_ANY_ACCESS)

/* 
This IOCTL used to clear process hide list.

Input string should be empty. 
*/

#define QUERY_SUCCESS 1
#define QUERY_FAIL    2

#define IOCTL_QUERY_PROCESS_HIDE_RULES CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x804, METHOD_BUFFERED, FILE_ANY_ACCESS)

/*
This IOCTL used to get process hide rule list.

Input string should be empty. 

Format of output string:
First byte contain type of information returned:
QUERY_SUCCESS or QUERY_FAIL
After this byte placed hide rules separated by '\n' character

Example:
    *;*;*\nSystem;*;* - two hide rules (*;*;*) and (System;*;*)
*/
/*-----------------------------------------------------------------------*/


/*-----------------------------------------------------------------------*/
/*                                File hide IOCTLs                       */

#define IOCTL_ADD_FILE_HIDE_RULE CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x901, METHOD_BUFFERED, FILE_ANY_ACCESS)

/*
This IOCTL used to add file hide rule to hide list.

Input string must be hide rule.
*/

#define IOCTL_DEL_FILE_HIDE_RULE CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x902, METHOD_BUFFERED, FILE_ANY_ACCESS)

/*
This IOCTL used to delete file hide rule from hide list.

Input string must be hide rule.
*/

#define IOCTL_CLEAR_FILE_HIDE_RULES CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x903, METHOD_BUFFERED, FILE_ANY_ACCESS)

/* 
This IOCTL used to clear file hide list.

Input string should be empty. 
*/

#define IOCTL_QUERY_FILE_HIDE_RULES CTL_CODE( \
    FILE_DEVICE_UNKNOWN, 0x904, METHOD_BUFFERED, FILE_ANY_ACCESS)

/*
This IOCTL used to get file hide rule list.

Input string should be empty. 

Format of output string same as in IOCTL_QUERY_PROCESS_HIDE_RULES.
*/

/*-----------------------------------------------------------------------*/


#endif // #ifndef HIDE_DRIVER_IOCTL_H_INCLUDED)