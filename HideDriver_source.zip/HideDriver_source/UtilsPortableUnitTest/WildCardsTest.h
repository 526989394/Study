#pragma once

namespace UnitTest
{

void WildCardsTestByTrustedResult();


}//namespace UnitTest