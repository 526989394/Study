#pragma once

namespace UnitTest
{

void GetTotalCountTest();

void CutFromListTest();

void ForEachTest();

void CutFromListIfTest();

void CutPairFromListTest();

}//namespace UnitTest