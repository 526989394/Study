#include "ListUtilsTest.h"
#include "ListUtils.h"
#include <boost/test/test_tools.hpp>

#include <vector>

namespace UnitTest
{
struct SimpleList
{
    size_t NextEntryOffset;
    size_t number;
    size_t body[256];
};
void GenerateTestData(std::vector<char>* buffer,size_t recordCount)
{
    size_t recordSize = sizeof(SimpleList);

    size_t dataSize = recordSize*recordCount;
    buffer->resize(dataSize);
    
    SimpleList* pList = (SimpleList*)&buffer->front();

    for(size_t i = 0; i< (recordCount-1) ; ++i)
    {
        pList->NextEntryOffset += recordSize;
        pList->number = i; 
        
        pList =  (SimpleList*)( (char*)pList + recordSize );
    }
    pList->NextEntryOffset = 0;
}
SimpleList* GetLastEntry(SimpleList* list)
{
	while( list->NextEntryOffset != 0 )
	{
		list = (SimpleList*)( (char*)list + list->NextEntryOffset);
	}
	return list;
}
/////////////////////////////////////////////////////////////////////////////////////

void GetTotalCountTest()
{
    std::vector<char> buffer;
    GenerateTestData(&buffer,5);

    utils::NtList* pList = (utils::NtList*)&buffer.front();

    BOOST_CHECK( utils::GetListEntryCount(pList) == 5 );
}

/////////////////////////////////////////////////////////////////////////////////////

void CutFirstEntry()
{
    std::vector<char> buffer;
    GenerateTestData(&buffer,5);
    utils::NtList* pList = (utils::NtList*)&buffer.front();

    utils::CutNextEntryByFakeOffset(pList);

    BOOST_CHECK( utils::GetListEntryCount(pList) == 4 );
}

void CutLastEntry()
{
    std::vector<char> buffer;
    GenerateTestData(&buffer,5);

    SimpleList* pList = (SimpleList*)&buffer.front();
    SimpleList* pLastEntry = GetLastEntry(pList);
    
    BOOST_CHECK_THROW( utils::CutNextEntryByFakeOffset((utils::NtList*)pLastEntry) ,std::exception );
}
void CutFromListTest()
{
    CutFirstEntry();
    CutLastEntry();
}
/////////////////////////////////////////////////////////////////////////////////////
void ListVisitor(utils::NtList* list,size_t* entryCount)
{
    *entryCount += 1;
}
void ForEachTest()
{
    std::vector<char> buffer;
    GenerateTestData(&buffer,5);
    utils::NtList* pList = (utils::NtList*)&buffer.front();

    size_t entryCount = 0;
    utils::ListForEach( pList, boost::bind(&ListVisitor,_1,&entryCount) );
    BOOST_CHECK(entryCount == 5);
    BOOST_CHECK(utils::GetListEntryCount(pList) == 5);
}
/////////////////////////////////////////////////////////////////////////////////////
bool CutListVisitor(utils::NtList* list)
{
    SimpleList* simpleList = (SimpleList*)list;
    if(simpleList->number == 2)
        return true;

    return false;
}
void CutFromListIfTest()
{
    std::vector<char> buffer;
    GenerateTestData(&buffer,5);
    utils::NtList* pList = (utils::NtList*)&buffer.front();

    utils::CutFromListByFakeOffset_If( pList, boost::bind(&CutListVisitor,_1) );
    BOOST_CHECK(utils::GetListEntryCount(pList) == 4);
}
/////////////////////////////////////////////////////////////////////////////////////
bool CutPairListVisitor(utils::NtList* list)
{
	SimpleList* simpleList = (SimpleList*)list;
	if(simpleList->number == 2 || simpleList->number == 3)
		return true;

	return false;
}
void CutPairFromListTest()
{
	std::vector<char> buffer;
	GenerateTestData(&buffer,5);
	utils::NtList* pList = (utils::NtList*)&buffer.front();

	utils::CutFromListByFakeOffset_If( pList, boost::bind(&CutPairListVisitor,_1) );
	BOOST_CHECK(utils::GetListEntryCount(pList) == 3);
}

}//namespace UnitTest