#include "PackageParserTest.h"
#include <boost/test/test_tools.hpp>

#include "PackageParser.h"

namespace UnitTest
{
void PackThreeToOne_SimpleTest()
/*++
Routine Description:
    PackThreeToOne test. Pack strings then unpack it and check for equal string.
--*/
{
    std::wstring packedString;

    std::wstring firstParamIn(L"FirstParam");
    std::wstring secondParamIn(L"SecondParam");
    std::wstring thirdParamIn(L"ThirdParam");
    utils::PackThreeToOne(firstParamIn,secondParamIn,thirdParamIn,&packedString);

    std::wstring firstParamOut;
    std::wstring secondParamOut;
    std::wstring thirdParamOut;
    utils::UnPackThreeToOne(packedString,&firstParamOut,&secondParamOut,&thirdParamOut);
    
    BOOST_REQUIRE(firstParamIn.size() == firstParamOut.size());
    BOOST_CHECK( std::equal(firstParamIn.begin(),firstParamIn.end(),firstParamOut.begin()) );
    
    BOOST_REQUIRE(secondParamIn.size() == secondParamOut.size());
    BOOST_CHECK( std::equal(secondParamIn.begin(),secondParamIn.end(),secondParamOut.begin()) );
    
    BOOST_REQUIRE(thirdParamIn.size() == thirdParamOut.size());
    BOOST_CHECK( std::equal(thirdParamIn.begin(),thirdParamIn.end(),thirdParamOut.begin()) );
}

#define PACK_CHECK_THROW(P1,P2,P3,P4) \
    BOOST_CHECK_THROW( utils::PackThreeToOne(P1,P2,P3,P4),std::exception )

void PackThreeToOne_WrongParameterTest()
/*++
Routine Description:
    Test wrong parameter passed to function PackThreeToOne().
--*/
{
    std::wstring packedString;

    std::wstring firstParamIn;
    std::wstring secondParamIn;
    std::wstring thirdParamIn;

/* Test empty strings*/

    // First param empty
    PACK_CHECK_THROW(firstParamIn,secondParamIn,thirdParamIn,&packedString);

    // Second param empty
    firstParamIn = L"1";
    PACK_CHECK_THROW(firstParamIn,secondParamIn,thirdParamIn,&packedString);

    // Third param empty
    secondParamIn = L"2";
    PACK_CHECK_THROW(firstParamIn,secondParamIn,thirdParamIn,&packedString);

/* Test illegal symbols*/
    thirdParamIn = L"3";

    // First param with illegal characters
    firstParamIn = L"ab;cd";
    PACK_CHECK_THROW(firstParamIn,secondParamIn,thirdParamIn,&packedString);

    // Second param with illegal characters
    firstParamIn = L"abcd";
    secondParamIn = L"ab;cd";
    PACK_CHECK_THROW(firstParamIn,secondParamIn,thirdParamIn,&packedString);

    // Third param with illegal characters
    secondParamIn = L"abcd";
    thirdParamIn = L"ab;cd";
    PACK_CHECK_THROW(firstParamIn,secondParamIn,thirdParamIn,&packedString);
}

#define UNPACK_CHECK_THROW(P1,P2,P3,P4) \
    BOOST_CHECK_THROW( utils::UnPackThreeToOne(P1,P2,P3,P4),std::exception )

void UnPackThreeToOne_WrongParameterTest()
/*++
Routine Description:
    Test wrong parameter passed to function UnPackThreeToOne.
--*/
{
    std::wstring packedString;

/* Test empty params */
    std::wstring firstParamOut;
    std::wstring secondParamOut;
    std::wstring thirdParamOut;

    // Without separators
    packedString = L"FirstParam";
    UNPACK_CHECK_THROW(packedString,&firstParamOut,&secondParamOut,&thirdParamOut);

    // One separator
    packedString = L"FirstParam;SecondParam";
    UNPACK_CHECK_THROW(packedString,&firstParamOut,&secondParamOut,&thirdParamOut);

    // First param empty
    packedString = L";SecondParam;ThirdParam";
    UNPACK_CHECK_THROW(packedString,&firstParamOut,&secondParamOut,&thirdParamOut);

    // Second param empty
    packedString = L"FirstParam;;ThirdParam";
    UNPACK_CHECK_THROW(packedString,&firstParamOut,&secondParamOut,&thirdParamOut);

    // Third param empty
    packedString = L"FirstParam;SecondParam;";
    UNPACK_CHECK_THROW(packedString,&firstParamOut,&secondParamOut,&thirdParamOut);
}

/////////////////////////////////////////////////////////////////////////////////////////

void PackByComma_SimpleTestImpl(const WStringList& stringListIn)
{
    std::wstring packedString;
    utils::PackByComma(stringListIn,&packedString);

    WStringList stringListOut;
    utils::UnPackByComma(packedString,&stringListOut);

    BOOST_REQUIRE(stringListOut.size() == stringListIn.size());
    BOOST_CHECK( std::equal(stringListIn.begin(),stringListIn.end(),stringListOut.begin()) );
}
void PackByComma_SimpleTest1()
{
    WStringList stringListIn;
    stringListIn.push_back(L"SingleValue");

    PackByComma_SimpleTestImpl(stringListIn);
}
void PackByComma_SimpleTest3()
{
    WStringList stringListIn;
    stringListIn.push_back(L"FirstValue");
    stringListIn.push_back(L"SecondValue");
    stringListIn.push_back(L"ThirdValue");

    PackByComma_SimpleTestImpl(stringListIn);
}
void PackByComma_SimpleTest()
/*++
Routine Description:
    PackThreeToOne test strings by comma then unpack it and check for equal string
--*/
{
    PackByComma_SimpleTest1();
    PackByComma_SimpleTest3();
}

#define PACK_BY_COMMA_CHECK_THROW(P1,P2) \
    BOOST_CHECK_THROW( utils::PackByComma(P1,P2),std::exception )

void PackByComma_WrongParameterTest()
/*++
Routine Description:
    Test wrong parameter passed to PackByComma function
--*/
{
    std::wstring packedString;
    WStringList stringListIn;

    // Empty string list
    PACK_BY_COMMA_CHECK_THROW(stringListIn,&packedString);

    // Empty value inside string list
    stringListIn.push_back(L"");
    PACK_BY_COMMA_CHECK_THROW(stringListIn,&packedString);
}

#define UNPACK_BY_COMMA_CHECK_THROW(X,Y) \
    BOOST_CHECK_THROW( utils::UnPackByComma(X,Y),std::exception )

void UnPackByComma_WrongParameterTest()
/*++
Routine Description:
    Test wrong parameter passed to UnPackByComma function
--*/
{
    std::wstring packedString;
    WStringList stringListOut;

    // Empty packed string
    UNPACK_BY_COMMA_CHECK_THROW(packedString,&stringListOut);

    // Second param empty
    packedString = L"abcd,";
    UNPACK_BY_COMMA_CHECK_THROW(packedString,&stringListOut);

    // First param empty
    packedString = L",abcd";
    UNPACK_BY_COMMA_CHECK_THROW(packedString,&stringListOut);

    // Middle param empty
    packedString = L"abcd,,abcd";
    UNPACK_BY_COMMA_CHECK_THROW(packedString,&stringListOut);
}
}//namespace UnitTest