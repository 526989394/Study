#include "WildCardsTest.h"
#include <boost/test/test_tools.hpp>

#include "WildCards.h"
#include <iostream>

namespace UnitTest
{
struct Mask
{
    wchar_t* mask;
    bool result[10];
};
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
wchar_t* target[10]={        L"C:\\A.A",      L"test.exe",   L"world.html",     L"h.exe",      L"readme",       L".err",     L"test3.exe",    L"text.txt", L"helloworld.txt", L"closeme"};
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask0   ={ L"*.*",     {   true,          true,           true,            true,           false,         true,           true,           true,           true,          false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask1   ={ L"*.txt",   {   false,         false,          false,           false,          false,         false,          false,          true,           true,          false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask2   ={ L"*.exe",   {   false,         true,           false,           true,           false,         false,          true,           false,          false,         false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask3   ={ L"*.html",  {   false,         false,          true,            false,          false,         false,          false,          false,          false,         false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask4   ={ L"test.*",  {   false,         true,           false,           false,          false,         false,          false,          false,          false,         false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask5   ={ L"test?.*", {   false,         false,          false,           false,          false,         false,          true,           false,          false,         false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask6   ={ L"r**",     {   false,         false,          false,           false,          true,          false,          false,          false,          false,         false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask7   ={ L".??r",    {   false,         false,          false,           false,          false,         true,           false,          false,          false,         false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask8   ={ L"*",       {   true,          true,           true,            true,           true,          true,           true,           true,           true,          true        }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask9   ={ L"h?l?o?o*",{   false,         false,          false,           false,          false,         false,          false,          false,          true,          false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
Mask mask10  ={ L"C:\\*",   {   true,          false,          false,           false,          false,         false,          false,          false,          false,         false       }};
//                          |             |               |               |               |               |               |               |               |               |               |
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

void FormatError(wchar_t* mask,wchar_t* target, bool expectedResult)
{
    std::wstring error = L"Error mask not correct. Mask: \"";
    error += mask;
    error += L"\" Target: \"";
    error += target;
    error += L"\" Expected Result: ";
    error += expectedResult?L"true":L"false";
    error += L"\n";

    std::wcout << error.c_str();
    BOOST_CHECK_MESSAGE(false,"");
}
void TestImpl(wchar_t* maskIn,bool* resultIn)
{
    // Loop for enumerating targets
    for( size_t i = 0 ; i<10 ; ++i )
    {
        bool res = utils::ApplyWildCards(maskIn,target[i]);
        if( res != resultIn[i] )
            FormatError(maskIn,target[i],resultIn[i]);
    }
}
void WildCardsTestByTrustedResult()
{ 
    TestImpl(mask0.mask,mask0.result);
    TestImpl(mask1.mask,mask1.result);
    TestImpl(mask2.mask,mask2.result);
    TestImpl(mask3.mask,mask3.result);
    TestImpl(mask4.mask,mask4.result);
    TestImpl(mask5.mask,mask5.result);
    TestImpl(mask6.mask,mask6.result);
    TestImpl(mask7.mask,mask7.result);
    TestImpl(mask8.mask,mask8.result);
	TestImpl(mask9.mask,mask9.result);
	TestImpl(mask10.mask,mask10.result);
}
}//namespace UnitTest