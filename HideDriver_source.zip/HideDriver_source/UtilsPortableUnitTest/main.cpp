#include <boost/test/included/unit_test.hpp>
using namespace boost::unit_test;

#include "PackageParserTest.h"
#include "WildCardsTest.h"
#include "ListUtilsTest.h"

using namespace UnitTest;

test_suite*
init_unit_test_suite( int argc, char* argv[] )
{
	test_suite* packageSuite = BOOST_TEST_SUITE( "PackageParserTestSuite" );
	packageSuite->add( BOOST_TEST_CASE( &PackThreeToOne_SimpleTest ) );
	packageSuite->add( BOOST_TEST_CASE( &PackThreeToOne_WrongParameterTest ) );
	packageSuite->add( BOOST_TEST_CASE( &UnPackThreeToOne_WrongParameterTest ) );
	packageSuite->add( BOOST_TEST_CASE( &PackByComma_SimpleTest ) );
	packageSuite->add( BOOST_TEST_CASE( &PackByComma_WrongParameterTest ) );
	packageSuite->add( BOOST_TEST_CASE( &UnPackByComma_WrongParameterTest ) );

	test_suite* maskSuite = BOOST_TEST_SUITE( "MaskTestSuite" );
	maskSuite->add( BOOST_TEST_CASE( &WildCardsTestByTrustedResult ) );

	test_suite* listSuite = BOOST_TEST_SUITE( "ListUtilsTestSuite" );
	maskSuite->add( BOOST_TEST_CASE( &GetTotalCountTest ) );
	maskSuite->add( BOOST_TEST_CASE( &CutFromListTest ) );
	maskSuite->add( BOOST_TEST_CASE( &ForEachTest ) );
	maskSuite->add( BOOST_TEST_CASE( &CutFromListIfTest ) );
	maskSuite->add( BOOST_TEST_CASE( &CutPairFromListTest ) );

	framework::master_test_suite().add( packageSuite );
	framework::master_test_suite().add( maskSuite );
	framework::master_test_suite().add( listSuite );

	return 0;
}