#pragma once

namespace UnitTest
{

void PackThreeToOne_SimpleTest();
void PackThreeToOne_WrongParameterTest();
void UnPackThreeToOne_WrongParameterTest();    

void PackByComma_SimpleTest();
void PackByComma_WrongParameterTest();
void UnPackByComma_WrongParameterTest();

}//namespace UnitTest