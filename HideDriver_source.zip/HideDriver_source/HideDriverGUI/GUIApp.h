#pragma once

#include "resource.h"

class CGUIApp : public CWinApp
{
public:
    CGUIApp();

// Overrides
public:
    virtual BOOL InitInstance();

// Implementation
    DECLARE_MESSAGE_MAP()
};

extern CGUIApp theApp;