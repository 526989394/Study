#pragma once
#include "afxwin.h"

enum ADD_DLG_OWNER
{
	TYPE_PROCESS,
	TYPE_FILE
};

// AddDlg dialog

class AddDlg : public CDialog
{
    DECLARE_DYNAMIC(AddDlg)

	CEdit mEditName;
	CEdit mEditUser;
	CEdit mEditProcess;

	CButton mButName;
	CButton mButUser;
	CButton mButProcess;

	CButton mCheckUser;
	CButton mCheckProcess;

	int mDlgType;
public:
    AddDlg(int DlgType,CWnd* pParent = NULL);   // standard constructor
    virtual ~AddDlg();

// Dialog Data
    enum { IDD = IDD_ADDDLG };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

    DECLARE_MESSAGE_MAP()
private:

	bool ValidateParameters();

public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonAdd();
    afx_msg void OnBnClickedButtonCancel();
    afx_msg void OnBnClickedCheckUser();
    afx_msg void OnBnClickedCheckProcess();
	afx_msg void OnBnClickedButtonName();
	afx_msg void OnBnClickedButtonUser();
	afx_msg void OnBnClickedButtonProcess();

    struct _ReturnData
    {
        CString Name;
        CString User;
        CString Process;
    }mReturnData;

protected:
    virtual void OnOK();
};
