#include "stdafx.h"
#include "GUIApp.h"

#include "GUIDoc.h"
#include "GUIView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGUIView
IMPLEMENT_DYNCREATE(CGUIView, CView)

BEGIN_MESSAGE_MAP(CGUIView, CView)
END_MESSAGE_MAP()

// CGUIView construction/destruction

CGUIView::CGUIView()
{
}

CGUIView::~CGUIView()
{
}

BOOL CGUIView::PreCreateWindow(CREATESTRUCT& cs)
{
    // TODO: Modify the Window class or styles here by modifying
    //  the CREATESTRUCT cs

    return CView::PreCreateWindow(cs);
}

// CGUIView drawing

void CGUIView::OnDraw(CDC* /*pDC*/)
{
    CGUIDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    if (!pDoc)
        return;
}


// CGUIView diagnostics

#ifdef _DEBUG
void CGUIView::AssertValid() const
{
    CView::AssertValid();
}

void CGUIView::Dump(CDumpContext& dc) const
{
    CView::Dump(dc);
}

CGUIDoc* CGUIView::GetDocument() const // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGUIDoc)));
    return (CGUIDoc*)m_pDocument;
}
#endif //_DEBUG