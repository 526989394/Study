#if !defined(AFX_TABBARCTRL_H__6934CAF5_EB26_4807_8C72_2902432EB3E2__INCLUDED_)
#define AFX_TABBARCTRL_H__6934CAF5_EB26_4807_8C72_2902432EB3E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabBarCtrl.h : header file
//
#pragma warning( disable : 4244  )

/////////////////////////////////////////////////////////////////////////////
// CTabBarCtrl window
#include <afxtempl.h>

class CTabBarCtrl : public CControlBar
{
// Construction
    DECLARE_DYNAMIC(CTabBarCtrl)
public:
    CTabBarCtrl();
    BOOL Create(CFrameWnd* pParentWnd);

private:
    int m_cyDefault;
    BOOL m_bSendInitialUpdate;
    BOOL GetItem(int iItem, TCITEMHEADER* pBarItem) const;
    int SetInfo(UINT uiType, int iItem, TCITEM *pTabCtrlItem);
    int SetInfo(UINT uiType, int iItem, TCITEMHEADER* pBarItem);
    int QueryInfo(UINT uiType, int iItem, TCITEM *pTabCtrlItem);
    int QueryInfo(UINT uiType, int iItem, TCITEMHEADER* pBarItem);
    UINT GetViewTabID(CWnd* pWnd);
    CMap<UINT, UINT, UINT, UINT> m_mapUsedID;
    CWnd* GetViewFromItem(int iItem);
    BOOL CreateView(CRuntimeClass *pViewClass, TCITEMHEADER* pBarItem, CCreateContext *pContext);
    void EnableDocking(DWORD dwDockStyle);

// Implementation
public:
    CWnd* GetItemView(int iItem);
    BOOL SetItemText(int iItem, CString csText);
    int SetItemImage(int iItem, UINT uiImage);
    BOOL SetItemData(int iItem, LPARAM lParam);

    DWORD GetItemState(int iItem, DWORD dwMask) const;
    BOOL SetItemState(int iItem, DWORD dwMask, DWORD dwState);

    CImageList* GetImageList() const;
    CImageList* SetImageList(CImageList* pImageList);
    int GetItemCount() const;
    BOOL GetItem(int iItem, TCITEM* pTabCtrlItem) const;
    BOOL SetItem(int iItem, TCITEM* pTabCtrlItem);
    BOOL GetItemRect(int iItem, LPRECT lpRect) const;
    int GetCurSel() const;
    int SetCurSel(int iItem);
    void SetCurFocus(int iItem);
    CSize SetItemSize(CSize size);
    void SetPadding(CSize size);
    CToolTipCtrl* GetToolTips() const;
    void SetToolTips(CToolTipCtrl* pWndTip);
    int GetCurFocus() const;
    int SetMinTabWidth(int cx);
    DWORD GetExtendedStyle();
    DWORD SetExtendedStyle(DWORD dwNewStyle, DWORD dwExMask = 0);
    
    // Operations
    int InsertView(CRuntimeClass *pViewClass, int iItem, LPCTSTR lpszItem, CCreateContext* pContext = NULL);
    int InsertView(CRuntimeClass *pViewClass, int iItem, LPCTSTR lpszItem, int iImage, CCreateContext* pContext = NULL);
    int InsertView(CRuntimeClass *pViewClass, UINT uiMask, int iItem, 
                    LPCTSTR lpszItem, int iImage, LPARAM lParam, CCreateContext* pContext = NULL);
    int InsertView(CRuntimeClass *pViewClass, UINT uiMask, int iItem, LPCTSTR lpszItem, 
                    int iImage, LPARAM lParam, DWORD dwState, DWORD dwStateMask, CCreateContext* pContext = NULL);

    int InsertView(CRuntimeClass *pViewClass, int iItem, TCITEM* pTabCtrlItem, CCreateContext* pContext = NULL);

    int AddView(CRuntimeClass *pViewClass, LPCTSTR lpszItem, CCreateContext* pContext = NULL);
    int AddView(CRuntimeClass *pViewClass, LPCTSTR lpszItem, int iImage, CCreateContext* pContext = NULL);
    int AddView(CRuntimeClass *pViewClass, LPCTSTR lpszItem, int iImage, LPARAM lParam, CCreateContext* pContext = NULL);
    int AddView(CRuntimeClass *pViewClass, UINT uiMask, LPCTSTR lpszItem, int iImage, 
                    LPARAM lParam, DWORD dwState, DWORD dwStateMask, CCreateContext* pContext = NULL);
    
    int AddView(CRuntimeClass *pViewClass, TCITEM* pTabCtrlItem, CCreateContext* pContext = NULL);

    BOOL RemoveView(int iItem);
    BOOL RemoveAllViews();
    void AdjustRect(BOOL bLarger, LPRECT lpRect);
    void RemoveImage(int iImage);
    int HitTest(TCHITTESTINFO* pHitTestInfo) const;
    BOOL HighlightItem(int idItem, BOOL fHighlight = TRUE);

public:
protected:
//    UINT m_uiItemHeight;

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CTabBarCtrl)
    public:
        virtual BOOL OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult);
    protected:
    //}}AFX_VIRTUAL

// Overridables
    virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
    virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);

// Implementation
public:
    virtual ~CTabBarCtrl();

    // Generated message map functions
protected:
    CFrameWnd *m_pParentFrame;
    //{{AFX_MSG(CTabBarCtrl)
    afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
    afx_msg void OnNcPaint();
    afx_msg void OnDestroy();
    afx_msg void OnPaint();
    //}}AFX_MSG
    afx_msg LRESULT OnSizeParent(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnInitialUpdate(WPARAM wParam, LPARAM lParam);
    afx_msg void OnSelchange(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg LRESULT OnDoNothing(WPARAM wParam, LPARAM lParam);
    DECLARE_MESSAGE_MAP()
};
#include "TabBarCtrl.inl"

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABBARCTRL_H__6934CAF5_EB26_4807_8C72_2902432EB3E2__INCLUDED_)
