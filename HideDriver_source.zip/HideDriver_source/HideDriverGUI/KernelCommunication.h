#pragma once

#include <string>
#include <list>

struct HideRule
{
	std::wstring name;
	std::wstring accessProc;
	std::wstring accessUser;
};
typedef std::list<HideRule> HideRuleList;

class KernelCommunication
{
public:
	static void AddRule(size_t ioctlCode,const HideRule& hideRule);
	
	static void DeleteRule(size_t ioctlCode,const HideRule& hideRule);

	static void DeleteAllRules(size_t ioctlCode);
	
	static void QueryRules(size_t ioctlCode,HideRuleList* ruleList);
};