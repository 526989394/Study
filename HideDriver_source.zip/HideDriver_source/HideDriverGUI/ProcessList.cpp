#include "stdafx.h"
#include "GUIApp.h"
#include "ProcessList.h"

#include "tlhelp32.h" // for CreateToolhelp32Snapshot

#include "HandleGuard.h" // utils

// ProcessList dialog

IMPLEMENT_DYNAMIC(ProcessList, CDialog)
ProcessList::ProcessList(CWnd* pParent /*=NULL*/)
    : CDialog(ProcessList::IDD, pParent)
{
}

ProcessList::~ProcessList()
{
}

void ProcessList::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_LIST_USERS, processList_);
}


BEGIN_MESSAGE_MAP(ProcessList, CDialog)

    ON_BN_CLICKED(IDC_BUTTON_OK, OnBnClickedButtonOk)
    ON_BN_CLICKED(IDC_BUTTON_CANCEL, OnBnClickedButtonCancel)
END_MESSAGE_MAP()


// ProcessList message handlers

BOOL ProcessList::OnInitDialog()
{
    CDialog::OnInitDialog();
    SetWindowText(_T("Local Processes"));

    processList_.InsertColumn(0,_T("Image Name"),LVCFMT_LEFT,100,0);
    processList_.InsertColumn(1,_T("PID"),LVCFMT_LEFT,100,1);


    DWORD dwExStyle_f=processList_.GetExtendedStyle();
    dwExStyle_f= (LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
    processList_.SetExtendedStyle(dwExStyle_f);

    UpdateProcessList();

    return TRUE;  // return TRUE unless you set the focus to a control
    // EXCEPTION: OCX Property Pages should return FALSE
}
void ProcessList::UpdateProcessList(void)
{
    CString str;
    int nIndex = processList_.GetItemCount();

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPALL,NULL);
    if(hSnapshot == INVALID_HANDLE_VALUE ) 
        return ;

    utils::HandleGuard guard(hSnapshot);

    PROCESSENTRY32 pe = {sizeof(pe)}; 
    BOOL fOK = Process32First(hSnapshot,&pe); // FirstProcess always ignored
    while(Process32Next(hSnapshot,&pe))
    {
        // Process Name
        str.Format(_T("%ws"),pe.szExeFile);
        processList_.InsertItem(nIndex,str);
        // Process PID
        str.Format(_T("%d"),pe.th32ProcessID);
        processList_.SetItemText(nIndex,1,str);

        ++nIndex;
    }
    
}
void ProcessList::OnOK()
{
	OnBnClickedButtonOk();
}
void ProcessList::OnBnClickedButtonOk()
{
    selectedProcesses_.clear();
    POSITION pos = processList_.GetFirstSelectedItemPosition();
    if (pos == NULL)
    {
        CDialog::OnOK();
        return;
    }

    while (pos)
    {
        int nItem = processList_.GetNextSelectedItem(pos);
        CString ProcessName = processList_.GetItemText(nItem,0);

        PWCHAR str = (PWCHAR)ProcessName.GetString();

        if(!selectedProcesses_.empty())
            selectedProcesses_+=L',';

        selectedProcesses_+=str;
    }
    CDialog::OnOK();
}

void ProcessList::OnBnClickedButtonCancel()
{
    CDialog::OnCancel();
}
const std::wstring& ProcessList::GetSelectedProcesses()const
{
	return selectedProcesses_;
}