#include "stdafx.h"
#include "GUIApp.h"
#include "GUIDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGUIDoc

IMPLEMENT_DYNCREATE(CGUIDoc, CDocument)

BEGIN_MESSAGE_MAP(CGUIDoc, CDocument)
END_MESSAGE_MAP()


// CGUIDoc construction/destruction

CGUIDoc::CGUIDoc()
{
    // TODO: add one-time construction code here

}

CGUIDoc::~CGUIDoc()
{
}

BOOL CGUIDoc::OnNewDocument()
{
    if (!CDocument::OnNewDocument())
        return FALSE;

    return TRUE;
}


// CGUIDoc serialization

void CGUIDoc::Serialize(CArchive& ar)
{
    if (ar.IsStoring())
    {
        // TODO: add storing code here
    }
    else
    {
        // TODO: add loading code here
    }
}

// CGUIDoc diagnostics

#ifdef _DEBUG
void CGUIDoc::AssertValid() const
{
    CDocument::AssertValid();
}

void CGUIDoc::Dump(CDumpContext& dc) const
{
    CDocument::Dump(dc);
}
#endif //_DEBUG