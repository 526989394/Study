#pragma once
#include "afxcmn.h"
#include <string>

class ProcessList : public CDialog
{
    DECLARE_DYNAMIC(ProcessList)

	CListCtrl processList_;
	std::wstring selectedProcesses_;
public:
    ProcessList(CWnd* pParent = NULL);   // standard constructor
    virtual ~ProcessList();

	const std::wstring& GetSelectedProcesses()const;

// Dialog Data
    enum { IDD = IDD_PROCESSLIST };

private:
	void UpdateProcessList();

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

    DECLARE_MESSAGE_MAP()
public:
    virtual BOOL OnInitDialog();
    afx_msg void OnBnClickedButtonOk();
    afx_msg void OnBnClickedButtonCancel();

protected:
	virtual void OnOK();
};
