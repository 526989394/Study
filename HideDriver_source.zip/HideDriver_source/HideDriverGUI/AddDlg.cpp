#include "stdafx.h"
#include "GUIApp.h"
#include "AddDlg.h"
#include "UserList.h"
#include "ProcessList.h"
// AddDlg dialog


IMPLEMENT_DYNAMIC(AddDlg, CDialog)
AddDlg::AddDlg(int DlgType,CWnd* pParent /*=NULL*/)
    : CDialog(AddDlg::IDD, pParent),mDlgType(DlgType)
{}

AddDlg::~AddDlg()
{}

void AddDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_EDIT_NAME, mEditName);
    DDX_Control(pDX, IDC_EDIT_USER, mEditUser);
    DDX_Control(pDX, IDC_EDIT_PROCESS, mEditProcess);
    DDX_Control(pDX, IDC_BUTTON_NAME, mButName);
    DDX_Control(pDX, IDC_BUTTON_USER, mButUser);
    DDX_Control(pDX, IDC_BUTTON_PROCESS, mButProcess);
    DDX_Control(pDX, IDC_CHECK_USER, mCheckUser);
    DDX_Control(pDX, IDC_CHECK_PROCESS, mCheckProcess);
}

BEGIN_MESSAGE_MAP(AddDlg, CDialog)
    ON_BN_CLICKED(IDC_BUTTON_ADD, OnBnClickedButtonAdd)
    ON_BN_CLICKED(IDC_BUTTON_CANCEL, OnBnClickedButtonCancel)
    ON_BN_CLICKED(IDC_CHECK_USER, OnBnClickedCheckUser)
    ON_BN_CLICKED(IDC_CHECK_PROCESS, OnBnClickedCheckProcess)
    ON_BN_CLICKED(IDC_BUTTON_NAME, OnBnClickedButtonName)
    ON_BN_CLICKED(IDC_BUTTON_USER, OnBnClickedButtonUser)
    ON_BN_CLICKED(IDC_BUTTON_PROCESS, OnBnClickedButtonProcess)
END_MESSAGE_MAP()


#pragma warning (push)
// warning C4996: 'wcstombs': This function or variable may be unsafe 
#pragma warning( disable:4996 ) 

void CheckForIllegalSymbol(const CString& parameter,
						   const char* parameterName,
						   wchar_t illegalSymbolW)
{
	if(parameter.Find(illegalSymbolW) != -1)
	{
		char illegalSymbolA;
		wcstombs(&illegalSymbolA,&illegalSymbolW,1);

		std::string error = parameterName;
		error += " string contain illegal symbol: ";
		error += '\'' + illegalSymbolA + '\'';

		throw std::runtime_error(error);
	}
}

#pragma warning (pop)

bool AddDlg::ValidateParameters()
{
    if( mReturnData.Name.GetLength() == 0)
    {
        AfxMessageBox(_T("Name string can't be empty"));
        return false;
    }

	try
	{
		wchar_t valueSeparator = L',';
		wchar_t paramsSeparator = L';';
		wchar_t ruleSeparator = L'\n';

		CheckForIllegalSymbol(mReturnData.Name,"Name",valueSeparator);
		CheckForIllegalSymbol(mReturnData.Name,"Name",ruleSeparator);

		CheckForIllegalSymbol(mReturnData.User,"User",paramsSeparator);
		CheckForIllegalSymbol(mReturnData.User,"User",ruleSeparator);

		CheckForIllegalSymbol(mReturnData.Process,"Process",paramsSeparator);
		CheckForIllegalSymbol(mReturnData.Process,"Process",ruleSeparator);

		return true;
	}
	catch(const std::exception& ex)
	{
		::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
	}

    return false;
}
void AddDlg::OnBnClickedButtonAdd()
{
    GetDlgItemText(IDC_EDIT_NAME,mReturnData.Name);
    
    if(mCheckUser.GetCheck())
        GetDlgItemText(IDC_EDIT_USER,mReturnData.User);
    if(mCheckProcess.GetCheck())
        GetDlgItemText(IDC_EDIT_PROCESS,mReturnData.Process);

    if(ValidateParameters() == false)
        return;

    if(mReturnData.User.GetLength() == 0)
        mReturnData.User = L'*';
    if(mReturnData.Process.GetLength() == 0)
        mReturnData.Process = L'*';
    
    // Close window
    CDialog::OnOK();
}

void AddDlg::OnBnClickedButtonCancel()
{
    OnCancel();
}

BOOL AddDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    mEditUser.EnableWindow(FALSE);
    mButUser.EnableWindow(FALSE);

    mEditProcess.EnableWindow(FALSE);
    mButProcess.EnableWindow(FALSE);


    if (mDlgType == TYPE_PROCESS)
    {
        SetDlgItemText(IDC_STATIC_NAME,_T("Process name"));
    }
    else if(mDlgType == TYPE_FILE)
        SetDlgItemText(IDC_STATIC_NAME,_T("File path"));
    else
        return FALSE;

    return TRUE; 
}

void AddDlg::OnBnClickedCheckUser()
{
    UINT state = mCheckUser.GetCheck();

    mEditUser.EnableWindow(state);
    mButUser.EnableWindow(state);
}

void AddDlg::OnBnClickedCheckProcess()
{
    UINT state = mCheckProcess.GetCheck();

    mEditProcess.EnableWindow(state);
    mButProcess.EnableWindow(state);
}

void AddDlg::OnBnClickedButtonName()
{
    if(mDlgType == TYPE_FILE)
    {
        DWORD flags =    OFN_HIDEREADONLY |
                        OFN_ALLOWMULTISELECT |
                        OFN_ENABLESIZING;
        CFileDialog fl_dlg(true,NULL,NULL,flags);
        if(fl_dlg.DoModal() != IDOK )
            return;

        CString file_path=fl_dlg.GetPathName();

        SetDlgItemText(IDC_EDIT_NAME,file_path);
    }
    else
    {
        ProcessList ProcessListDlg;

        if(ProcessListDlg.DoModal() == IDOK )
        {
            const WCHAR* pStr = ProcessListDlg.selectedProcesses_.data();
            CString strProcesses(pStr);

            SetDlgItemText(IDC_EDIT_NAME,strProcesses);
        }
    }
}

void AddDlg::OnBnClickedButtonUser()
{
    UserList UserListDlg;
    if(UserListDlg.DoModal() == IDOK )
    {
        const std::wstring& users = UserListDlg.GetSelectedUsers();
        const WCHAR* pStr = users.c_str();
        CString strUsers(pStr);

        SetDlgItemText(IDC_EDIT_USER,strUsers);
    }
}

void AddDlg::OnBnClickedButtonProcess()
{
    ProcessList ProcessListDlg;

    if(ProcessListDlg.DoModal() == IDOK )
    {
        const WCHAR* pStr = ProcessListDlg.selectedProcesses_.data();
        CString strProcesses(pStr);

        SetDlgItemText(IDC_EDIT_PROCESS,strProcesses);
    }
}

void AddDlg::OnOK()
{
    OnBnClickedButtonAdd();
}
