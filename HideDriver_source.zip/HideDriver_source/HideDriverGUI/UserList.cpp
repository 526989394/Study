#include "stdafx.h"
#include "GUIApp.h"
#include "UserList.h"
#include "UserWork.h"

// UserList dialog

IMPLEMENT_DYNAMIC(UserList, CDialog)
UserList::UserList(CWnd* pParent /*=NULL*/)
    : CDialog(UserList::IDD, pParent)
{
}

UserList::~UserList()
{
}

void UserList::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_LIST_USERS, userList_);
}


BEGIN_MESSAGE_MAP(UserList, CDialog)
    ON_BN_CLICKED(IDC_BUTTON_OK, OnBnClickedButtonOk)
    ON_BN_CLICKED(IDC_BUTTON_CANCEL, OnBnClickedButtonCancel)
END_MESSAGE_MAP()


BOOL UserList::OnInitDialog()
{
    CDialog::OnInitDialog();
    SetWindowText(_T("Local Users"));

    userList_.InsertColumn(0,_T("Name"),LVCFMT_LEFT,130,0);
    userList_.InsertColumn(1,_T("SID"),LVCFMT_LEFT,280,1);
    DWORD dwExStyle_f=userList_.GetExtendedStyle();
    dwExStyle_f= (LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
    userList_.SetExtendedStyle(dwExStyle_f);

    UpdateUsers();

    return TRUE;  // return TRUE unless you set the focus to a control
    // EXCEPTION: OCX Property Pages should return FALSE
}
void UserList::UpdateUsers()
{
    CString str;
    int nIndex = userList_.GetItemCount();

    utils::UserNameSidList userList;
    utils::GetUserNames(&userList);

    utils::UserNameSidList::const_iterator it = userList.begin();
    for( ;userList.end()!=it ; ++it )
    {
        // User Name
        str.Format(_T("%ws"),it->first.c_str());
        userList_.InsertItem(nIndex,str);
        // User SID
        str.Format(_T("%ws"),it->second.c_str());
        userList_.SetItemText(nIndex,1,str);

        ++nIndex;
    }
}

void UserList::OnBnClickedButtonOk()
{
    selectedUsers_.clear();
    POSITION pos = userList_.GetFirstSelectedItemPosition();
    if (pos == NULL)
    {
        CDialog::OnOK();
        return;
    }

    while (pos)
    {
        int nItem = userList_.GetNextSelectedItem(pos);
        CString UserSID = userList_.GetItemText(nItem,0);

        PWCHAR str = (PWCHAR)UserSID.GetString();

        if(!selectedUsers_.empty())
            selectedUsers_+=L',';

        selectedUsers_+=str;
    }
    
    CDialog::OnOK();
}
void UserList::OnBnClickedButtonCancel()
{
    CDialog::OnCancel();
}
void UserList::OnOK()
{
	OnBnClickedButtonOk();
}

const std::wstring& UserList::GetSelectedUsers()const
{
	return selectedUsers_;
}