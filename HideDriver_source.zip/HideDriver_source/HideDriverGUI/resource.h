//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GUI.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_INSTALLFORM                 103
#define IDD_PROCESSFORM                 104
#define IDD_RULEFORM                    105
#define IDD_ADDDLG                      106
#define IDD_USERLIST                    107
#define IDD_PROCESSLIST                 108
#define IDD_TESTFORM                    109
#define IDR_MAINFRAME                   128
#define IDR_GUITYPE                     129
#define IDR_MENU_LIST                   130
#define IDC_EDIT_PATH                   1001
#define IDC_BUT_PATH_SELECT             1002
#define IDC_EDIT_NAME                   1003
#define IDC_COMBO_TYPE                  1004
#define IDC_BUT_INST                    1005
#define IDC_BUT_UNINST                  1006
#define IDC_BUT_RUN                     1007
#define IDC_BUT_STOP                    1008
#define IDC_STATIC_STATUS               1009
#define IDC_LIST_PROCESS                1010
#define IDC_LIST_FILE                   1011
#define IDC_BUTTON_NAME                 1013
#define IDC_BUTTON_ADD                  1014
#define IDC_BUTTON_OK                   1014
#define IDC_BUTTON_CANCEL               1015
#define IDC_EDIT_USER                   1016
#define IDC_EDIT_MISSED_CALS            1016
#define IDC_BUTTON_USER                 1017
#define IDC_EDIT_PROCESS                1018
#define IDC_BUTTON_PROCESS              1019
#define IDC_CHECK_USER                  1020
#define IDC_CHECK_PROCESS               1021
#define IDC_STATIC_NAME                 1022
#define IDC_LIST_USERS                  1023
#define IDC_COMBO_MODE                  1025
#define ID_MENU_ADD                     32773
#define ID_MENU_DELEATE                 32775
#define ID_MENU_QUERY                   32780
#define ID_MENU_DELEATE_ALL             32781
#define ID_MENU_CANCEL                  32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
