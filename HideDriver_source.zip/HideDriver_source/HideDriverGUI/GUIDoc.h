#pragma once

class CGUIDoc : public CDocument
{
protected: // create from serialization only
    CGUIDoc();
    DECLARE_DYNCREATE(CGUIDoc)

// Attributes
public:

// Operations
public:

// Overrides
    public:
    virtual BOOL OnNewDocument();
    virtual void Serialize(CArchive& ar);

// Implementation
public:
    virtual ~CGUIDoc();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
    DECLARE_MESSAGE_MAP()
};


