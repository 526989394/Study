#include "stdafx.h"
#include "GUIApp.h"

#include "MainFrm.h"

// Additional forms
#include "InstallForm.h"
#include "FileRuleForm.h"
#include "ProcessRuleForm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
END_MESSAGE_MAP()


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
    // TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
    if(cs.hMenu!=NULL)
    {
        ::DestroyMenu(cs.hMenu); // ������� ����, ���� ���������
        cs.hMenu = NULL; // ��� ����� ���� ���� ���
    }
    // Set window position
    cs.x = 50;    // Left
    cs.cx = 450;// Right

    cs.y = 50;    // Top
    cs.cy = 280;// Bottom
    
    return CFrameWnd::PreCreateWindow(cs);
} 


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
    if(!m_wndTabBar.Create(this))
    {
        return FALSE;
    }

    // AddView
    CRuntimeClass *pClass = RUNTIME_CLASS(InstallForm);
    int iIndx = m_wndTabBar.AddView(pClass, _T("Install"), pContext);
    if(iIndx < 0)
    {
        TRACE(_T("Dynamic creation of the %s view failed.\n"), pClass->m_lpszClassName);

        return FALSE;
    }

    pClass = RUNTIME_CLASS(ProcessRuleForm);
    iIndx = m_wndTabBar.AddView(pClass, _T("Process"), pContext);
    if(iIndx < 0)
    {
        TRACE(_T("Dynamic creation of the %s view failed.\n"), pClass->m_lpszClassName);

        return FALSE;
    }

    pClass = RUNTIME_CLASS(FileRuleForm);
    iIndx = m_wndTabBar.AddView(pClass, _T("Files"), pContext);
    if(iIndx < 0)
    {
        TRACE(_T("Dynamic creation of the %s view failed.\n"), pClass->m_lpszClassName);

        return FALSE;
    }

    return TRUE;
}
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
    CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
    CFrameWnd::Dump(dc);
}

#endif //_DEBUG

// CMainFrame message handlers

