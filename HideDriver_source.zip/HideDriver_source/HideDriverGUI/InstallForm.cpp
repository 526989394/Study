#include "stdafx.h"
#include "GUIApp.h"
#include "InstallForm.h"
#include "DriverWork.h"
#include <exception>
// InstallForm

IMPLEMENT_DYNCREATE(InstallForm, CFormView)

BEGIN_MESSAGE_MAP(InstallForm, CFormView)
    ON_BN_CLICKED(IDC_BUT_PATH_SELECT, OnBnClickedButPathSelect)
    ON_BN_CLICKED(IDC_BUT_INST, OnBnClickedButInst)
    ON_BN_CLICKED(IDC_BUT_UNINST, OnBnClickedButUninst)
    ON_BN_CLICKED(IDC_BUT_RUN, OnBnClickedButRun)
    ON_BN_CLICKED(IDC_BUT_STOP, OnBnClickedButStop)
END_MESSAGE_MAP()

InstallForm::InstallForm()
    : CFormView(InstallForm::IDD)
{
}

InstallForm::~InstallForm()
{
}

void InstallForm::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
}

void InstallForm::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    //SetDlgItemText(IDC_EDIT_PATH,_T("C:\\Windows\\System32\\Drivers\\HideDriver.sys"));
	SetDlgItemText(IDC_EDIT_PATH,_T("C:\\DriverDev\\HideDriver.sys"));
	SetDlgItemText(IDC_EDIT_NAME,_T("HideDriver"));
    SetDlgItemText(IDC_COMBO_TYPE,_T("SERVICE_DEMAND_START"));
}

// InstallForm message handlers
void InstallForm::OnBnClickedButPathSelect()
{
    CFileDialog fl_dlg(true);
    if(fl_dlg.DoModal() != IDOK )
        return;

    CString file_path=fl_dlg.GetPathName();

    SetDlgItemText(IDC_EDIT_PATH,file_path);
    int nIndex = file_path.ReverseFind(L'\\');
    if(nIndex != -1)
    {
        ++nIndex;
        CString strName;
        strName = file_path.Mid(nIndex);
        SetDlgItemText(IDC_EDIT_NAME,strName);
    }
    else
        SetDlgItemText(IDC_EDIT_NAME,_T(""));
}
// Driver installation
void InstallForm::OnBnClickedButInst()
{
    CString strName,strPath,strStartType;
    DWORD startType;
    // Get input parameters
    GetDlgItemText(IDC_EDIT_PATH,strPath);
    if(strPath.GetLength() == NULL)
    {
        AfxMessageBox(_T("Path is empty"));
        return;
    }
    GetDlgItemText(IDC_EDIT_NAME,strName);
    if(strName.GetLength() == NULL)
    {
        AfxMessageBox(_T("Name is empty"));
        return;
    }
    GetDlgItemText(IDC_COMBO_TYPE,strStartType);
    if(strStartType == _T("SERVICE_AUTO_START"))
        startType = SERVICE_AUTO_START;
    else if(strStartType == _T("SERVICE_BOOT_START"))
        startType = SERVICE_BOOT_START;
    else if(strStartType == _T("SERVICE_DEMAND_START"))
        startType = SERVICE_DEMAND_START;
    else if(strStartType == _T("SERVICE_DISABLED"))
        startType = SERVICE_DISABLED;
    else if(strStartType == _T("SERVICE_SYSTEM_START"))
        startType = SERVICE_SYSTEM_START;
    else
    {
        AfxMessageBox(_T("Wrong start type"));
        return;
    }

    // Try to install driver
    try
    {
        utils::DriverWork::Install(strName,strPath,startType);
    }
    catch(const std::exception& ex)
    {
        ::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
        SetDlgItemText(IDC_STATIC_STATUS,_T("Cannot install"));
        return;
    }

    SetDlgItemText(IDC_STATIC_STATUS,_T("Installed"));
}
void InstallForm::OnBnClickedButUninst()
{
    CString strName,strPath;
    // Get input parameters
    GetDlgItemText(IDC_EDIT_PATH,strPath);
    if(strPath.GetLength() == NULL)
    {
        AfxMessageBox(_T("Path is empty"));
        return;
    }
    GetDlgItemText(IDC_EDIT_NAME,strName);
    if(strName.GetLength() == NULL)
    {
        AfxMessageBox(_T("Name is empty"));
        return;
    }

    try
    {
        utils::DriverWork::Remove(strName,strPath);
    }
    catch(const std::exception& ex)
    {
        ::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
        SetDlgItemText(IDC_STATIC_STATUS,_T("Cannot uninstall"));
        return;
    }
    SetDlgItemText(IDC_STATIC_STATUS,_T("Uninstaled"));
}

// Driver control
void InstallForm::OnBnClickedButRun()
{
    CString strName;
    // Get input parameters
    GetDlgItemText(IDC_EDIT_NAME,strName);
    if(strName.GetLength() == NULL)
    {
        AfxMessageBox(_T("Name is empty"));
        return;
    }

    try
    {
        utils::DriverWork::Start(strName);
    }
    catch(const std::exception& ex)
    {
        ::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
        SetDlgItemText(IDC_STATIC_STATUS,_T("Cannot start"));
        return;
    }
    SetDlgItemText(IDC_STATIC_STATUS,_T("Started"));
}

void InstallForm::OnBnClickedButStop()
{    
    CString strName;
    // Get input parameters
    GetDlgItemText(IDC_EDIT_NAME,strName);
    if(strName.GetLength() == NULL)
    {
        AfxMessageBox(_T("Name is empty"));
        return;
    }

    try
    {
        utils::DriverWork::Stop(strName);
    }
    catch(const std::exception& ex)
    {
        ::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
        SetDlgItemText(IDC_STATIC_STATUS,_T("Cannot stop"));
        return;
    }
    SetDlgItemText(IDC_STATIC_STATUS,_T("Stoped"));
}

// InstallForm diagnostics

#ifdef _DEBUG
void InstallForm::AssertValid() const
{
    CFormView::AssertValid();
}

void InstallForm::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif //_DEBUG
