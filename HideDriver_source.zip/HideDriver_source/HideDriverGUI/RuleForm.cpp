#include "stdafx.h"
#include "GUIApp.h"
#include "RuleForm.h"
#include "AddDlg.h"
#include "KernelCommunication.h"

// RuleForm

IMPLEMENT_DYNCREATE(RuleForm, CFormView)

RuleForm::RuleForm()
    : CFormView(RuleForm::IDD)
{
}

RuleForm::~RuleForm()
{
}

void RuleForm::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_LIST_FILE, mListCtrl);
}

BEGIN_MESSAGE_MAP(RuleForm, CFormView)
    ON_NOTIFY(NM_RCLICK, IDC_LIST_FILE, OnNMRclickListCtrl)
    ON_COMMAND(ID_MENU_DELEATE, OnMenuDeleate)
    ON_COMMAND(ID_MENU_ADD, OnMenuAdd)
    ON_COMMAND(ID_MENU_QUERY, OnMenuQuery)
    ON_COMMAND(ID_MENU_DELEATE_ALL, OnMenuDeleateAll)
END_MESSAGE_MAP()


// RuleForm diagnostics

#ifdef _DEBUG
void RuleForm::AssertValid() const
{
    CFormView::AssertValid();
}

void RuleForm::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif //_DEBUG


// RuleForm message handlers

enum 
{
	NameColumn,
	ProcessFileterColumn,
	UserFilterColumn
};

void RuleForm::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

	std::wstring name = GetNameColumn();
    mListCtrl.InsertColumn(NameColumn,name.c_str(),LVCFMT_LEFT,150,NameColumn);
	mListCtrl.InsertColumn(ProcessFileterColumn,_T("Process Filter"),LVCFMT_LEFT,100,ProcessFileterColumn);
    mListCtrl.InsertColumn(UserFilterColumn,_T("User Filter"),LVCFMT_LEFT,100,UserFilterColumn);

    DWORD dwExStyle_f=mListCtrl.GetExtendedStyle();
    dwExStyle_f= (LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
    mListCtrl.SetExtendedStyle(dwExStyle_f);
}

void RuleForm::OnNMRclickListCtrl(NMHDR *pNMHDR, LRESULT *pResult)
{
    CPoint point; 
    GetCursorPos( &point); 
    CMenu menu;
    menu.LoadMenu(IDR_MENU_LIST);

    POSITION pos = mListCtrl.GetFirstSelectedItemPosition();
    if(pos == NULL)
        menu.EnableMenuItem(ID_MENU_DELEATE,TRUE);

    if(mListCtrl.GetItemCount() == 0)
        menu.EnableMenuItem(ID_MENU_DELEATE_ALL,TRUE);

    menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point.x, point.y, this);    

    *pResult = 0;
}

void RuleForm::OnMenuAdd()
{
    AddDlg dlg(GetAddDlgOwnerType());
    if( dlg.DoModal() != IDOK )
        return;

    // Prepare string
	HideRule newRule = {dlg.mReturnData.Name.GetBuffer(),
						dlg.mReturnData.Process.GetBuffer(),
						dlg.mReturnData.User.GetBuffer()};
	try
	{
		KernelCommunication::AddRule(GetIOCTLCode(ADD_RULE),newRule);
	}
	catch(const std::exception& ex)
	{
		::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
		return;
	}

    int nIndex = mListCtrl.GetItemCount();
    mListCtrl.InsertItem(nIndex,newRule.name.c_str());
    mListCtrl.SetItemText(nIndex,ProcessFileterColumn,newRule.accessProc.c_str());
	mListCtrl.SetItemText(nIndex,UserFilterColumn,newRule.accessUser.c_str());
}

void RuleForm::OnMenuDeleate()
{
    POSITION pos = mListCtrl.GetFirstSelectedItemPosition();
    if (pos == NULL)
        return;

	// Multi select support
    while (pos)
    {
        int nItem = mListCtrl.GetNextSelectedItem(pos);

        // Prepare rule
		HideRule rule = {mListCtrl.GetItemText(nItem,NameColumn).GetBuffer(),
						 mListCtrl.GetItemText(nItem,ProcessFileterColumn).GetBuffer(),
						 mListCtrl.GetItemText(nItem,UserFilterColumn).GetBuffer()};
		try
		{
			KernelCommunication::DeleteRule(GetIOCTLCode(DELETE_RULE),rule);
		}
		catch(const std::exception& ex)
		{
			::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
			OnMenuQuery(); // Update rules
			return;
		}
    }

	// Delete all selected items
	mListCtrl.LockWindowUpdate();
    pos = mListCtrl.GetFirstSelectedItemPosition();
    while(pos)
    {
        mListCtrl.DeleteItem(mListCtrl.GetNextSelectedItem(pos));
		pos = mListCtrl.GetFirstSelectedItemPosition();
    }
	mListCtrl.UnlockWindowUpdate();
}

void RuleForm::OnMenuDeleateAll()
{
	try
	{
		KernelCommunication::DeleteAllRules(GetIOCTLCode(DELETE_ALL_RULES));
	}
	catch(const std::exception& ex)
	{
		::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
		OnMenuQuery(); // Update rules
		return;
	}

    mListCtrl.DeleteAllItems();
}

void UpdateRuleList(const HideRuleList& ruleList, CListCtrl* listCtrl)
{
	listCtrl->DeleteAllItems();

	HideRuleList::const_iterator it = ruleList.begin();
	for( ; it != ruleList.end() ; ++it )
	{
		int nIndex = listCtrl->GetItemCount();
		listCtrl->InsertItem(nIndex,it->name.c_str());
		listCtrl->SetItemText(nIndex,ProcessFileterColumn,it->accessProc.c_str());
		listCtrl->SetItemText(nIndex,UserFilterColumn,it->accessUser.c_str());
	}
}

void RuleForm::OnMenuQuery()
{
	HideRuleList ruleList;
	try
	{
		KernelCommunication::QueryRules(GetIOCTLCode(QUERY_RULES),&ruleList);
	}
	catch(const std::exception& ex)
	{
		::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
		return;
	}

	try
	{
		UpdateRuleList(ruleList,&mListCtrl);
	}
	catch(const std::exception& ex)
	{
		::MessageBoxA(this->GetSafeHwnd(),ex.what(),"Error",MB_ICONERROR|MB_OK);
	}
}