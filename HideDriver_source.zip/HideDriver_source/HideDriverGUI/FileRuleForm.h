#pragma once
#include "RuleForm.h"

class FileRuleForm : public RuleForm
{
    DECLARE_DYNCREATE(FileRuleForm)

	CListCtrl mListCtrl;
protected:
	FileRuleForm(); // protected constructor used by dynamic creation

protected:
	ULONG GetIOCTLCode(IOCTLCodeType codeType);
	std::wstring GetNameColumn();
	int GetAddDlgOwnerType();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};