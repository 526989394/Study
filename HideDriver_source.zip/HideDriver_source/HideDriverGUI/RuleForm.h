#pragma once
#include "afxcmn.h"
#include "resource.h"
// RuleForm form view

#include <string>

class RuleForm : public CFormView
{
    DECLARE_DYNCREATE(RuleForm)

	CListCtrl mListCtrl;
protected:
    RuleForm();           // protected constructor used by dynamic creation
    virtual ~RuleForm();

public:
    enum { IDD = IDD_RULEFORM };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

    DECLARE_MESSAGE_MAP()
public:
    virtual void OnInitialUpdate();
    afx_msg void OnNMRclickListCtrl(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnMenuDeleate();
    afx_msg void OnMenuAdd();
    afx_msg void OnMenuQuery();
    afx_msg void OnMenuDeleateAll();

protected:
	enum IOCTLCodeType
	{
		ADD_RULE,
		DELETE_RULE,
		DELETE_ALL_RULES,
		QUERY_RULES
	};
	// Class can't be abstract because used DECLARE_DYNCREATE & IMPLEMENT_DYNCREATE
	virtual ULONG GetIOCTLCode(IOCTLCodeType codeType){ThrowMustBeOvverided();return 0;}
	virtual std::wstring GetNameColumn(){ThrowMustBeOvverided();return std::wstring();}
	virtual int GetAddDlgOwnerType(){ThrowMustBeOvverided();return 0;}
private:
	void ThrowMustBeOvverided(){throw std::exception("Class can't be used directly.");}

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};


