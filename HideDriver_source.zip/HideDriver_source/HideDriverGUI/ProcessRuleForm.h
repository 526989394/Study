#pragma once
#include "RuleForm.h"

class ProcessRuleForm : public RuleForm
{
    DECLARE_DYNCREATE(ProcessRuleForm)

	CListCtrl mListCtrl;
protected:
	ProcessRuleForm(); // protected constructor used by dynamic creation

protected:
	ULONG GetIOCTLCode(IOCTLCodeType codeType);
	std::wstring GetNameColumn();
	int GetAddDlgOwnerType();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};