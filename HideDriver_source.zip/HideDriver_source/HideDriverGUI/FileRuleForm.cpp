#include "stdafx.h"
#include "FileRuleForm.h"
#include "AddDlg.h"
#include "winioctl.h"
#include "Ioctl.h"

IMPLEMENT_DYNCREATE(FileRuleForm,RuleForm)

FileRuleForm::FileRuleForm()
{}

ULONG FileRuleForm::GetIOCTLCode(IOCTLCodeType codeType)
{
	switch(codeType)
	{
	case ADD_RULE:
		return IOCTL_ADD_FILE_HIDE_RULE;
	case DELETE_RULE:
		return IOCTL_DEL_FILE_HIDE_RULE;
	case DELETE_ALL_RULES:
		return IOCTL_CLEAR_FILE_HIDE_RULES;
	case QUERY_RULES:
		return IOCTL_QUERY_FILE_HIDE_RULES;
	default:
		throw std::exception("Unknown IOCTL code type");
	}
}
std::wstring FileRuleForm::GetNameColumn()
{
	return std::wstring(L"File path");
}
int FileRuleForm::GetAddDlgOwnerType()
{
	return TYPE_FILE;
}

// ProcessRuleForm diagnostics

#ifdef _DEBUG
void FileRuleForm::AssertValid() const
{
	RuleForm::AssertValid();
}

void FileRuleForm::Dump(CDumpContext& dc) const
{
	RuleForm::Dump(dc);
}

#endif //_DEBUG