#pragma once

class InstallForm : public CFormView
{
    DECLARE_DYNCREATE(InstallForm)

protected:
    InstallForm();           // protected constructor used by dynamic creation
    virtual ~InstallForm();
public:
    enum { IDD = IDD_INSTALLFORM };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

    DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedButPathSelect();
    afx_msg void OnBnClickedButInst();
    afx_msg void OnBnClickedButUninst();
    afx_msg void OnBnClickedButRun();
    afx_msg void OnBnClickedButStop();
    virtual void OnInitialUpdate();

#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif
};


