#include "stdafx.h"
#include "ProcessRuleForm.h"
#include "AddDlg.h"
#include "winioctl.h"
#include "Ioctl.h"

IMPLEMENT_DYNCREATE(ProcessRuleForm,RuleForm)

ProcessRuleForm::ProcessRuleForm()
{}

ULONG ProcessRuleForm::GetIOCTLCode(IOCTLCodeType codeType)
{
	switch(codeType)
	{
	case ADD_RULE:
		return IOCTL_ADD_PROCESS_HIDE_RULE;
	case DELETE_RULE:
		return IOCTL_DEL_PROCESS_HIDE_RULE;
	case DELETE_ALL_RULES:
		return IOCTL_CLEAR_PROCESS_HIDE_RULES;
	case QUERY_RULES:
		return IOCTL_QUERY_PROCESS_HIDE_RULES;
	default:
		throw std::exception("Unknown IOCTL code type");
	}
}
std::wstring ProcessRuleForm::GetNameColumn()
{
	return std::wstring(L"Process name");
}
int ProcessRuleForm::GetAddDlgOwnerType()
{
	return TYPE_PROCESS;
}

// ProcessRuleForm diagnostics

#ifdef _DEBUG
void ProcessRuleForm::AssertValid() const
{
	RuleForm::AssertValid();
}

void ProcessRuleForm::Dump(CDumpContext& dc) const
{
	RuleForm::Dump(dc);
}

#endif //_DEBUG