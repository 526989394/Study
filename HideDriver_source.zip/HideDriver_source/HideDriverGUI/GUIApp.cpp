#include "stdafx.h"
#include "GUIApp.h"
#include "MainFrm.h"

#include "GUIDoc.h"
#include "GUIView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGUIApp
BEGIN_MESSAGE_MAP(CGUIApp, CWinApp)
END_MESSAGE_MAP()


// CGUIApp construction
CGUIApp::CGUIApp()
{
}


// The one and only CGUIApp object
CGUIApp theApp;

// CGUIApp initialization
BOOL CGUIApp::InitInstance()
{
    // InitCommonControls() is required on Windows XP if an application
    // manifest specifies use of ComCtl32.dll version 6 or later to enable
    // visual styles.  Otherwise, any window creation will fail.
    InitCommonControls();

    CWinApp::InitInstance();

    // Standard initialization
    // If you are not using these features and wish to reduce the size
    // of your final executable, you should remove from the following
    // the specific initialization routines you do not need
    // Change the registry key under which our settings are stored
    SetRegistryKey(_T("ApriorIT inc."));
    LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)
    // Register the application's document templates.  Document templates
    //  serve as the connection between documents, frame windows and views
    CSingleDocTemplate* pDocTemplate;
    pDocTemplate = new CSingleDocTemplate(
        IDR_MAINFRAME,
        RUNTIME_CLASS(CGUIDoc),
        RUNTIME_CLASS(CMainFrame),       // main SDI frame window
        RUNTIME_CLASS(CGUIView));
    if (!pDocTemplate)
        return FALSE;
    AddDocTemplate(pDocTemplate);
    // Parse command line for standard shell commands, DDE, file open
    CCommandLineInfo cmdInfo;
    ParseCommandLine(cmdInfo);
    // Dispatch commands specified on the command line.  Will return FALSE if
    // app was launched with /RegServer, /Register, /Unregserver or /Unregister.
    if (!ProcessShellCommand(cmdInfo))
        return FALSE;
    // The one and only window has been initialized, so show and update it
    m_pMainWnd->SetWindowText(_T("HideDriver exchange utility"));
    m_pMainWnd->ShowWindow(SW_SHOW);
    m_pMainWnd->UpdateWindow();

    return TRUE;
}