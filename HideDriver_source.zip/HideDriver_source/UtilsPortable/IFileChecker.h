#pragma once

/* 
	Include before drvCommon.h for kernel mode
	or KernelDefines.h for user mode.
*/

namespace HideAlgorithm
{

struct NtQueryDirParams
{
    HANDLE FileHandle;
	HANDLE Event;
	PIO_APC_ROUTINE ApcRoutine;
	PVOID ApcContext;
	PIO_STATUS_BLOCK IoStatusBlock;
    PVOID FileInformation;
    ULONG FileInformationLength;
    FILE_INFORMATION_CLASS FileInformationClass;
    BOOLEAN ReturnSingleEntry;
	PUNICODE_STRING FileName;
    BOOLEAN RestartScan;
};

struct IFileChecker
{
    virtual bool 
    CheckFile( wchar_t* fileName
             , size_t nameSize
             , const NtQueryDirParams& params )=0;
};

}