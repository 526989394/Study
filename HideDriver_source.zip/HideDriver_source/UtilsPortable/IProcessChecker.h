#pragma once

/* 
	Include before drvCommon.h for kernel mode
	or KernelDefines.h for user mode.
*/

namespace HideAlgorithm
{

struct NtQuerySysInfoParams
{
	SYSTEM_INFORMATION_CLASS SystemInformationClass;
	PVOID SystemInformation;
	ULONG SystemInformationLength;
	PULONG ReturnLength;
};

struct IProcessChecker
{
    virtual bool 
    CheckProcess( wchar_t* imageName
                , size_t nameSize )=0;
};

}