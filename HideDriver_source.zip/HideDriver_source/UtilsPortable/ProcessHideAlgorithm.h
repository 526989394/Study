#pragma once

#include "IProcessChecker.h"
#include "ListUtils.h"

#include <boost/bind.hpp>
#include <vector>

namespace HideAlgorithm
{

inline bool 
CheckProcEntry( utils::NtList* list, 
                const NtQuerySysInfoParams& params, 
                IProcessChecker* checker )
{
    SYSTEM_PROCESSES_INFORMATION* info = 
        (SYSTEM_PROCESSES_INFORMATION*)list;

    return checker->CheckProcess(info->ProcessName.Buffer,
                                 info->ProcessName.Length/2);
}

inline NTSTATUS 
HideProcessImpl( const NtQuerySysInfoParams& params, 
                 IProcessChecker* checker )
{
    utils::NtList* pList = 
        (utils::NtList*)params.SystemInformation;

    // First entry always exist 
    // because first entry is idle process
    utils::CutFromListByFakeOffset_If(pList,    
        boost::bind(&CheckProcEntry,_1,params,checker));    

    return STATUS_SUCCESS;
}

inline NTSTATUS 
HideProcess( const NtQuerySysInfoParams& params, 
             IProcessChecker* checker )
{
    try
    {
        return HideProcessImpl(params,checker);
    }
    catch(const std::exception& ex)
    {
#ifdef KdPrint // For use in user mode environment
        KdPrint( (__FUNCTION__" std::exception: %s\n",ex.what()) );
#endif
    }
    return STATUS_SUCCESS;
}

}