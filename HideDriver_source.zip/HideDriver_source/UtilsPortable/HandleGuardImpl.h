#pragma once

#include "boost/noncopyable.hpp"

namespace utils
{
template<class HandleType,class CloseAction>
class HandleGuardImpl:public boost::noncopyable
{
    HandleType handle_;
public:
    HandleGuardImpl(HandleType handle)
        : handle_(handle)
    {}
    HandleGuardImpl()
        : handle_(NULL)
    {}
    virtual ~HandleGuardImpl()
    {
        if(handle_)
            CloseAction::Execute(handle_);
    }
    void reset(HandleType handle)
    {
        handle_ = handle;
    }
    HandleType get()
    {
        return handle_;
    }
    HandleType release()
    {
        HandleType handle = handle_;
        handle_ = NULL;
        return handle;
    }
};
}//namespace utils