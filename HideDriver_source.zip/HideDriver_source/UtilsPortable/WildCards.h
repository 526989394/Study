#pragma once

#include <string>
#include "wchar.h"
namespace utils
{
/*

http://en.wikipedia.org/wiki/Wildmat

wildmat is a pattern matching library developed by Rich Salz. 
Based on the wildcard syntax already used in the Bourne shell,
wildmat provides a uniform mechanism for matching patterns across 
applications with simpler syntax than that typically offered by regular expressions. 
Patterns are implicitly anchored at the beginning and end of each string when testing for a match.

*/

#define MATCH_TRUE	1
#define MATCH_FALSE 0
#define MATCH_ABORT -1

/* What character marks an inverted character class? */
#define NEGATE_CLASS           '^'

int DoMatch(const wchar_t *text, const wchar_t *p)
{
	int last;
	int matched;
	int reverse;
	for ( ; *p; text++, p++) 
	{
		if (*text == L'\0' && *p != L'*')
			return MATCH_ABORT;
		switch (*p) 
		{
		default:
			if ( _wcsnicmp(text,p,1) != 0 )
				return MATCH_FALSE;
			continue;
		case L'?':
			/* Match anything. */
			continue;
		case L'*':
			while (*++p == L'*')
				/* Consecutive stars act just like one. */
				continue;
			if (*p == L'\0')
				/* Trailing star matches everything. */
				return MATCH_TRUE;
			while (*text)
				if ((matched = DoMatch(text++, p)) != MATCH_FALSE)
					return matched;
			return MATCH_ABORT;
		case L'[':
			reverse = p[1] == NEGATE_CLASS ? MATCH_TRUE : MATCH_FALSE;
			if (reverse)
				/* Inverted character class. */
				p++;
			for (last = 0400, matched = MATCH_FALSE; *++p && *p != L']'; last = *p)
				/* This next line requires a good C compiler. */
				if (*p == L'-' ? *text <= *++p && *text >= last : *text == *p)
					matched = MATCH_TRUE;
			if (matched == reverse)
				return MATCH_FALSE;
			continue;
		}
	}

	return *text == L'\0';
}

bool wildmat(const wchar_t *text, const wchar_t *p)
{
	if (p[0] == L'*' && p[1] == L'\0')
		return MATCH_TRUE;

	return DoMatch(text, p) == MATCH_TRUE;
} 

inline bool
EqualWString(const wchar_t* mask, size_t maskSize,
			 const wchar_t* target, size_t targetSize)
{
	if(maskSize != targetSize)
		return false;

	return ( _wcsnicmp(mask,target,maskSize) == 0 );
}
inline bool
ApplyWildCards(const wchar_t* mask, size_t maskSize,
			   const wchar_t* target, size_t targetSize)
{
	if(maskSize == 0)
		throw std::exception(__FUNCTION__"Mask string can't be empty");

	if(targetSize == 0)
		throw std::exception(__FUNCTION__"Target string can't be empty");

	if(EqualWString(mask,maskSize,target,targetSize)) 
		return true;

	return wildmat(target,mask);
	//return WildCardsAlgorithm(mask,maskSize,target,targetSize);
}
inline bool
ApplyWildCards(const std::wstring& maskStr,const std::wstring& targetStr)
{
    return ApplyWildCards(&maskStr.at(0),maskStr.size(),&targetStr.at(0),targetStr.size());
}

}//namespace utils