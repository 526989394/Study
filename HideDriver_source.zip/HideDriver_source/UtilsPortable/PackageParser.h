#pragma once

#include <string>
#include <list>
#include <vector>

typedef std::list<std::wstring> WStringList;

namespace utils
{
inline void
CheckStringNotEmpty(const std::wstring& string,const char* exceptionMsg)
{
    if(string.size() == 0)
        throw std::exception(exceptionMsg);
}
inline void 
CheckForIllegalCharacter(const std::wstring& string,wchar_t illegalCharacte,const char* exceptionMsg)
{
    if( string.find(illegalCharacte) != std::wstring::npos )
        throw std::exception(exceptionMsg);
}
inline void
PackThreeToOne(const std::wstring& firstParam,
               const std::wstring& secondParam,
               const std::wstring& thirdParam,
               std::wstring* outputString)
{
    // Check for correct string length
    CheckStringNotEmpty(firstParam,"First parameter can't be empty");
    CheckStringNotEmpty(secondParam,"Second parameter can't be empty");
    CheckStringNotEmpty(thirdParam,"Third parameter can't be empty");

    // Check for illegal characters inside string
    CheckForIllegalCharacter(firstParam,L';',"First parameter contain illegal character \';\'");
    CheckForIllegalCharacter(secondParam,L';',"Second parameter contain illegal character \';\'");
    CheckForIllegalCharacter(thirdParam,L';',"Third parameter contain illegal character \';\'");

    // Copy params
    *outputString  = firstParam;
    *outputString += L';';
    *outputString += secondParam;
    *outputString += L';';
    *outputString += thirdParam;
}
inline void
UnPackThreeToOne(const std::wstring&  inputString,
                 std::wstring*  pStrFirstParam,
                 std::wstring*  pStrSecondParam,
                 std::wstring*  pStrThirdParam)
{
    // Find separator positions
    size_t nFirstSeparator  = inputString.find(L';',0);
    if( nFirstSeparator == std::wstring::npos )
        throw std::exception("Can't find first string separator");

    size_t nSecondSeparator = inputString.find(L';',nFirstSeparator+1);
    if( nSecondSeparator == std::wstring::npos )
        throw std::exception("Can't find second string separator");

    // Check string size
    if( nFirstSeparator == 0 )
        throw std::exception("First parameter can't be empty");

    if( (nFirstSeparator+1) == nSecondSeparator )
        throw std::exception("Second parameter can't be empty");

    if( (nSecondSeparator+1) == inputString.size() )
        throw std::exception("Third parameter can't be empty");
    
    // Copy strings
    size_t count = nFirstSeparator;
    *pStrFirstParam = std::wstring(&inputString.at(0),count);
    
    count = nSecondSeparator - nFirstSeparator - 1;
    *pStrSecondParam = std::wstring(&inputString.at(nFirstSeparator+1),count);

    count = inputString.size() - nSecondSeparator - 1;
    *pStrThirdParam = std::wstring(&inputString.at(nSecondSeparator+1),count);
}
inline void
PackAlgorithm( const WStringList& stringList
             , wchar_t separator
             , std::wstring* outputString)
{
    if(stringList.size() == 0)
        throw std::exception("String list can't be empty");

    WStringList::const_iterator it = stringList.begin();
    for( ; it != stringList.end() ; ++it)
    {
        CheckStringNotEmpty(*it,"String inside list can't be empty");
        CheckForIllegalCharacter(*it,separator,"One of string inside list contain separator");

        *outputString += it->data();
        
        // Do not add separator for last string
        WStringList::const_iterator next = it; 
        if( ++next != stringList.end())
            *outputString += separator;
    }
}
inline void 
PackByComma(const WStringList& stringList,std::wstring* outputString)
{
    PackAlgorithm(stringList,L',',outputString);
}
inline void
FindAllSeparators( const std::wstring& string
                 , wchar_t separator
                 , std::vector<size_t>* pSeparatorVect)
{
    size_t position = string.find(separator,0);
    while( position  != std::wstring::npos )
    {
        pSeparatorVect->push_back(position);
        position = string.find(separator,position+1);
    }
}
inline void
UnPackAlgorithm( const std::wstring& inputString
               , wchar_t separator
               , WStringList* stringList)
{
	CheckStringNotEmpty(inputString,"Input string can't be empty");
 
    std::vector<size_t> separatorVect;
    FindAllSeparators(inputString,separator,&separatorVect);

    if(separatorVect.empty())
    {
        // Input string don't have separators
        stringList->push_back(inputString);
        return;
    }

    // Add first separated string
    std::wstring firstValue(&inputString.at(0), separatorVect[0]); 
    stringList->push_back(firstValue);

    // Add middle separated string
    for(size_t i = 1 ; i < separatorVect.size() ; ++i )
    {
        size_t startPos = separatorVect[i-1] + 1; //Skip separator character
        size_t count = separatorVect[i] - startPos;
        std::wstring firstValue(&inputString.at(startPos), count); 
        stringList->push_back(firstValue);                
    }

    // Add last separated string
    size_t lastIndex = separatorVect.size()-1;
    size_t lastPos = separatorVect[lastIndex];
    size_t startPos = lastPos + 1; //Skip separator character
    std::wstring lastValue(&inputString.at(startPos),inputString.size() - startPos); 
    stringList->push_back(lastValue);
}
inline void 
UnPackByComma(const std::wstring& inputString, WStringList* stringList)
{
    UnPackAlgorithm(inputString,L',',stringList);

    WStringList::const_iterator it = stringList->begin();
    for( ; it != stringList->end() ; ++it )
    {
        CheckStringNotEmpty(*it,"One of unpacked string is empty.");
    }
}
inline void 
PackByEOL(const WStringList& stringList,std::wstring* outputString)
{
	PackAlgorithm(stringList,L'\n',outputString);
}
inline void 
UnPackByEOL(const std::wstring& inputString, WStringList* stringList)
{
	UnPackAlgorithm(inputString,L'\n',stringList);

	WStringList::const_iterator it = stringList->begin();
	for( ; it != stringList->end() ; ++it )
	{
		CheckStringNotEmpty(*it,"One of unpacked string is empty.");
	}
}
}//namespace utils