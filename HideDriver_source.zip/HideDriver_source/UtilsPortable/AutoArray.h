#pragma once

namespace utils
{
// auto_ptr like array wrapper
template<class _Ty>
class auto_array
{    
    _Ty *_MyArrayPtr;    // the wrapped object pointer
public:
    typedef _Ty element_type;

    explicit auto_array(_Ty *_ArrayPtr = 0)
        : _MyArrayPtr(_ArrayPtr)
    {    // construct from object pointer
    }

    auto_array(auto_array<_Ty>& _Right)
        : _MyArrayPtr(_Right.release())
    {    // construct by assuming pointer from _Right auto_array
    }

    auto_array<_Ty>& operator=(auto_array<_Ty>& _Right)
    {    // assign compatible _Right (assume pointer)
        reset(_Right.release());
        return (*this);
    }

    ~auto_array()
    {    // destroy the array of objects
        delete[] _MyArrayPtr;
    }

    _Ty& operator*() const
    {    // return designated value
        return (*_MyArrayPtr);
    }

    _Ty *operator->() const
    {    // return pointer to class object
        return (&**this);
    }

    _Ty *get() const
    {    // return wrapped pointer
        return (_MyArrayPtr);
    }

    _Ty *release()
    {    // return wrapped pointer and give up ownership
        _Ty *_Tmp = _MyArrayPtr;
        _MyArrayPtr = 0;
        return (_Tmp);
    }

    void reset(_Ty* _ArrayPtr = 0)
    {    // destroy designated object and store new pointer
        if (_ArrayPtr != _MyArrayPtr)
            delete[] _MyArrayPtr;
        _MyArrayPtr = _ArrayPtr;
    }
};
}