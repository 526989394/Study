#pragma once
#include "boost/function.hpp"
#include "boost/bind.hpp"

namespace utils
{

struct NtList
{
    size_t NextEntryOffset;
};

#define LastEntryOffset 0

inline bool IsEntryLast(NtList* pList) 
{
	return (pList->NextEntryOffset == LastEntryOffset);
}

////////////////////////////////////// FOR EACH SECTION ///////////////////////////

inline NtList* 
GetNextEntryPointer(NtList* list)
{
    if(list->NextEntryOffset == 0)
        throw std::exception("No more entries inside list");

    return (NtList*)((char*)list + list->NextEntryOffset);
}

template<class Visitor>
inline void 
ListForEach( NtList* list, Visitor visitor )
{
    while( true )
    {
        visitor(list); 

        if( IsEntryLast(list) )
            break;

        list = GetNextEntryPointer(list);
    }
}

///////////////////////////////// ENTRY COUNT SECTION /////////////////////////////

inline void 
CountEntryVisitor(NtList* list,size_t* entryCount)
{
    *entryCount += 1;
}

inline size_t 
GetListEntryCount(NtList* list)
{
    size_t count = 0;
    ListForEach(list,boost::bind(&CountEntryVisitor,_1,&count));
    return count;
}

////////////////////////////////// LIST SIZE SECTION /////////////////////////////

inline void 
SizeEntryVisitor(NtList* list,size_t* size)
{
	*size += list->NextEntryOffset;
}
inline size_t 
GetListSize(NtList* list)
{
	size_t size = 0;
	ListForEach(list,boost::bind(&SizeEntryVisitor,_1,&size));
	return size;
}

///////////////////////////////// CUT SECTION ////////////////////////////////////

inline void 
CutNextEntryByFakeOffset( NtList* list )
{
	NtList* pNextEntry = GetNextEntryPointer(list);

	if( IsEntryLast(pNextEntry) )
		list->NextEntryOffset = LastEntryOffset;
	else
		list->NextEntryOffset = list->NextEntryOffset + pNextEntry->NextEntryOffset;
}

template<class Checker>
inline void 
CutFromListByFakeOffset_IfImpl( NtList* list, 
							    Checker checker )
{
    if( IsEntryLast(list) )
        return; // Last entry already dispatched

	while(true)
	{
		NtList* pNextEntry = GetNextEntryPointer(list);
		if( !checker(pNextEntry) )
			break;

		CutNextEntryByFakeOffset(list);

		if( IsEntryLast(list) )
			break;
	}
}

template<class Checker>
inline void 
CutFromListByFakeOffset_If( NtList* list
						  , Checker checker )
{
    ListForEach( list, boost::bind(&CutFromListByFakeOffset_IfImpl<Checker>,_1,
                                   boost::ref(checker) ) );
}
}//namespace utils