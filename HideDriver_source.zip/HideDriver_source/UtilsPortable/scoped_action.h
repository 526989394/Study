#pragma once

#include <boost/function.hpp>
#include <boost/noncopyable.hpp>

namespace utils
{
class scoped_action:public boost::noncopyable
{
    typedef boost::function<void()> Action;
    Action action_;
public:
    scoped_action(Action action)
        : action_(action)
    {}
    ~scoped_action()
    {
        action_();
    }
};
}