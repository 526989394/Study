# if defined (_STLP_USE_NEW_IOSTREAMS)
using _STLP_NEW_IO_NAMESPACE::char_traits;
using _STLP_NEW_IO_NAMESPACE::basic_ios;
using _STLP_NEW_IO_NAMESPACE::basic_streambuf;
using _STLP_NEW_IO_NAMESPACE::basic_istream;
using _STLP_NEW_IO_NAMESPACE::basic_ostream;
using _STLP_NEW_IO_NAMESPACE::basic_iostream;
using _STLP_NEW_IO_NAMESPACE::basic_stringbuf;
using _STLP_NEW_IO_NAMESPACE::basic_istringstream;
using _STLP_NEW_IO_NAMESPACE::basic_ostringstream;
using _STLP_NEW_IO_NAMESPACE::basic_stringstream;
using _STLP_NEW_IO_NAMESPACE::basic_filebuf;
using _STLP_NEW_IO_NAMESPACE::basic_ifstream;
using _STLP_NEW_IO_NAMESPACE::basic_ofstream;
using _STLP_NEW_IO_NAMESPACE::basic_fstream;
using _STLP_NEW_IO_NAMESPACE::fpos;
using _STLP_NEW_IO_NAMESPACE::istreambuf_iterator;
using _STLP_NEW_IO_NAMESPACE::ostreambuf_iterator;
using _STLP_NEW_IO_NAMESPACE::stringbuf;
using _STLP_NEW_IO_NAMESPACE::istringstream;
using _STLP_NEW_IO_NAMESPACE::ostringstream;
using _STLP_NEW_IO_NAMESPACE::stringstream;
# endif

using _STLP_NEW_IO_NAMESPACE::ios;
using _STLP_NEW_IO_NAMESPACE::streambuf;
using _STLP_NEW_IO_NAMESPACE::istream;
using _STLP_NEW_IO_NAMESPACE::ostream;
using _STLP_NEW_IO_NAMESPACE::iostream;

using _STLP_NEW_IO_NAMESPACE::filebuf;
using _STLP_NEW_IO_NAMESPACE::ifstream;
using _STLP_NEW_IO_NAMESPACE::ofstream;
using _STLP_NEW_IO_NAMESPACE::fstream;

using _STLP_NEW_IO_NAMESPACE::streampos;
using _STLP_NEW_IO_NAMESPACE::streamoff;

# if !defined (_STLP_NO_WIDE_STREAMS)
using _STLP_NEW_IO_NAMESPACE::wios;
using _STLP_NEW_IO_NAMESPACE::wstreambuf;
using _STLP_NEW_IO_NAMESPACE::wistream;
using _STLP_NEW_IO_NAMESPACE::wostream;
using _STLP_NEW_IO_NAMESPACE::wiostream;
using _STLP_NEW_IO_NAMESPACE::wstringbuf;
using _STLP_NEW_IO_NAMESPACE::wistringstream;
using _STLP_NEW_IO_NAMESPACE::wostringstream;
using _STLP_NEW_IO_NAMESPACE::wstringstream;
using _STLP_NEW_IO_NAMESPACE::wfilebuf;
using _STLP_NEW_IO_NAMESPACE::wifstream;
using _STLP_NEW_IO_NAMESPACE::wofstream;
using _STLP_NEW_IO_NAMESPACE::wfstream;
using _STLP_NEW_IO_NAMESPACE::wstreampos;
# endif
