using _STLP_NEW_IO_NAMESPACE::basic_stringbuf;
using _STLP_NEW_IO_NAMESPACE::stringbuf;

using _STLP_NEW_IO_NAMESPACE::basic_istringstream;
using _STLP_NEW_IO_NAMESPACE::basic_ostringstream;
using _STLP_NEW_IO_NAMESPACE::basic_stringstream;
using _STLP_NEW_IO_NAMESPACE::istringstream;
using _STLP_NEW_IO_NAMESPACE::ostringstream;
using _STLP_NEW_IO_NAMESPACE::stringstream;

#ifndef _STLP_NO_WIDE_STREAMS
using _STLP_NEW_IO_NAMESPACE::wstringbuf;
using _STLP_NEW_IO_NAMESPACE::wistringstream;
using _STLP_NEW_IO_NAMESPACE::wostringstream;
using _STLP_NEW_IO_NAMESPACE::wstringstream;
#endif
