#pragma once

#include <string>
#include <vector>

namespace utils
{

void GetProcessImagePath(PEPROCESS proc,std::wstring* imagePath);

void GetCurrentProcessName(std::wstring* userName);

void GetCurrentUserSid(std::vector<char>* sid);

void GetUserNameBySid(const std::vector<char>& sid,std::wstring* userName);

}