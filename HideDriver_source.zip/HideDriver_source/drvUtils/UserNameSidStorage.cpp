#include "UserNameSidStorage.h"
#include "UserNameFromSIDUtils.h"

namespace utils
{
UserName UserNameSidStorage::RequestNewRecord(const UserSid& sid)
{
	utils::SectionWriteGuard guard(&mapLock_);

	// Check if other thread already founded name for this SID
	SidNameMap::const_iterator it = nameSidMap_.find(sid);
	if( it != nameSidMap_.end() )
		return it->second;

	std::wstring userName;
	utils::GetUserNameBySidUseNamesKey(sid,&userName);

	nameSidMap_.insert(SidNameMap::value_type(sid,userName));

	return userName;
}
void UserNameSidStorage::GetUserNameBySid(const UserSid& sid, UserName* userName)
{
	utils::SectionReadGuard guard(&mapLock_);
	
	SidNameMap::const_iterator it = nameSidMap_.find(sid);
	if( it == nameSidMap_.end() )
	{
		guard.release()->Done();

		*userName = RequestNewRecord(sid);
		
		return;
	}

	*userName = it->second;
}

}