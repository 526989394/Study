#ifndef VERSION_INDEPEND_OFFSETS_H_INCLUDED__
#define VERSION_INDEPEND_OFFSETS_H_INCLUDED__

namespace utils
{

void InitOffsets();

ULONG GetEprocessNameOffset();

}

#endif // VERSION_INDEPEND_OFFSETS_H_INCLUDED__