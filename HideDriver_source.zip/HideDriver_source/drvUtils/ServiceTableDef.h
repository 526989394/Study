#pragma once

extern "C"
{

typedef struct _SYSTEM_SERVICE_TABLE
{
    PNTPROC ServiceTable;
    PDWORD  CounterTable;
    ULONG   ServiceLimit;
    PBYTE   ArgumentTable;
}
SYSTEM_SERVICE_TABLE ,
    * PSYSTEM_SERVICE_TABLE ,
    * * PPSYSTEM_SERVICE_TABLE ;

typedef struct _SERVICE_DESCRIPTOR_TABLE {
    SYSTEM_SERVICE_TABLE ntoskrnl;  //SST for ntoskrnl.exe
    SYSTEM_SERVICE_TABLE win32k;    //SST for win32k.sys
    SYSTEM_SERVICE_TABLE unused1;
    SYSTEM_SERVICE_TABLE unused2;   
}
SERVICE_DESCRIPTOR_TABLE ,
    * PSERVICE_DESCRIPTOR_TABLE,
    * * PPSERVICE_DESCRIPTOR_TABLE ;

//import SSDT pointer
extern PSERVICE_DESCRIPTOR_TABLE KeServiceDescriptorTable;
PSYSTEM_SERVICE_TABLE pNtoskrnl = &(KeServiceDescriptorTable->ntoskrnl);
PNTPROC ServiceTable = pNtoskrnl->ServiceTable;

}// extern "C"