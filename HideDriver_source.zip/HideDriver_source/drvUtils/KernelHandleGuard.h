#pragma once

#include "HandleGuardImpl.h"

namespace utils
{
class CloseHandleAction
{
public:
    static void Execute(HANDLE handle)
    {
        ZwClose(handle);
    }
};
typedef HandleGuardImpl<HANDLE,CloseHandleAction> HandleGuard;

class ObjectCloseHandleAction
{
public:
    static void Execute(PVOID object)
    {
        ObDereferenceObject(object);
    }
};
typedef HandleGuardImpl<PVOID,ObjectCloseHandleAction> ObjectGuard;

class WorkItemHandleAction
{
public:
	static void Execute(PIO_WORKITEM workItem)
	{
		IoFreeWorkItem(workItem);
	}
};
typedef HandleGuardImpl<PIO_WORKITEM,WorkItemHandleAction> WorkItemGuard;

}