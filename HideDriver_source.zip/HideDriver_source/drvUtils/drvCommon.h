#pragma once

extern "C"
{
#define POINTER_64
#include "ntifs.h"
}
#include "new"
#include "libcpp.h"

extern "C"
{
    typedef PVOID* PNTPROC;
    typedef ULONG DWORD;
    typedef DWORD*    PDWORD;
    typedef unsigned char (BYTE);
    typedef BYTE* PBYTE;
    typedef unsigned short      WORD;
    typedef int                 INT;
    typedef unsigned int        UINT;
    typedef unsigned int        *PUINT;
}

#define MAX_PATH          260