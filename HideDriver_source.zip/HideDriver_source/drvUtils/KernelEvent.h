#pragma once

#include "drvCommon.h"
#include "KernelHandleGuard.h"
#include <boost/noncopyable.hpp>
#include <memory>

namespace utils
{

class KernelEvent: public boost::noncopyable
{
    std::auto_ptr<KEVENT> event_;
public:
    KernelEvent( EVENT_TYPE eventType, BOOLEAN state = FALSE )
        : event_(new KEVENT)
    {
        KeInitializeEvent(event_.get(),eventType,state);
    }
	void set()
	{
		KeSetEvent(event_.get(),EVENT_INCREMENT,FALSE);
	}
	void wait()
    {
        NTSTATUS status = 
            KeWaitForSingleObject( event_.get()
								 , Executive
								 , KernelMode
								 , FALSE
								 , NULL );
        if( status != STATUS_SUCCESS )
            throw std::exception(__FUNCTION__" fail.");
    }
};

class KernelNotificationEvent:public KernelEvent
{
public:
	KernelNotificationEvent(BOOLEAN state = FALSE)
		: KernelEvent(NotificationEvent,state)
	{}
};

class KernelSynchronizationEvent:public KernelEvent
{
public:
	KernelSynchronizationEvent(BOOLEAN state = FALSE)
		: KernelEvent(SynchronizationEvent,state)
	{}
};

}