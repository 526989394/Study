#pragma once

#include <vector>
#include <string>

namespace utils
{

void GetUserNameBySidUseNamesKey(const std::vector<char>& sid,std::wstring* userName);

void GetUserNameBySidUseVBlock(const std::vector<char>& sid,std::wstring* userNam);

}