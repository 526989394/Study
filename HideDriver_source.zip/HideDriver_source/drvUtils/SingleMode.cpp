#include "SingleMode.h"

SingleProcessorMode::SingleProcessorMode()
{
    mCpuCount = KeNumberProcessors;
    DpcArray = new KDPC[mCpuCount];
    if(mCpuCount > 1)
    {
        for(CCHAR i = 0; i < mCpuCount; i++)
        {
            KeInitializeDpc(&DpcArray[i], DpcRoutine, (PVOID)&mHub);
            KeSetImportanceDpc(&DpcArray[i], HighImportance);
            KeSetTargetProcessorDpc(&DpcArray[i], i);
        }
    }
}

void SingleProcessorMode::DpcRoutine(KDPC *pDpc, void *pContext, void *pArg1, void *pArg2)
{
    PLONG mHub = (PLONG )pContext;
    KIRQL Irql;

    // Indicate that we catch the processor
    InterlockedDecrement(mHub);
    
    //Wait until all our DPC will catch all processors    

    while(*mHub > 0);
    
    KeRaiseIrql(HIGH_LEVEL, &Irql);  // catch processor

    // value -1 in variable mHum indicate that useful work already done
    if(*mHub != -1)
    {
        // wait until useful work will be done
        while(*mHub >= 0);
    }

    KeLowerIrql(Irql);
    
}

void SingleProcessorMode::Enter()
{
    if(mCpuCount > 1)
    {
        KeEnterCriticalRegion();
    
        mSavedPriority = KeSetPriorityThread(KeGetCurrentThread(), HIGH_PRIORITY);
        KAFFINITY ActiveProcessors = KeQueryActiveProcessors();

        KeRaiseIrql(DISPATCH_LEVEL, &mSavedIrql);
        CCHAR CurrentProcessor = (CCHAR) KeGetCurrentProcessorNumber();
        
        mHub = 1;
        // Set for all processors except this DPC
        for(CCHAR i = mCpuCount - 1; i >= 0; i--)
        {
            if(i != CurrentProcessor && (ActiveProcessors & (1u << i)) != 0)
            {
                InterlockedIncrement(&mHub);
                KeInsertQueueDpc(&DpcArray[i], 0, 0);
            }
        }
        // Decrement mHub because this processor is catch        
        InterlockedDecrement(&mHub);

        // Lowering Irql for resolving DPC 
        // If Irql will be to high DPC will be never set
        KeLowerIrql(mSavedIrql);
        
        // Waiting until all DPC reach the target
        while(mHub > 0);

        KeRaiseIrql(HIGH_LEVEL, &mSavedIrql);
    }
    else
        KeRaiseIrql(HIGH_LEVEL, &mSavedIrql);
}

void SingleProcessorMode::Exit()
{
    if(mCpuCount > 1)
    {
        // value -1 indicate that all useful work are done
        InterlockedExchange(&mHub, -1);
        KeLowerIrql(mSavedIrql);
        KeSetPriorityThread(KeGetCurrentThread(), mSavedPriority);
        
        KeLeaveCriticalRegion();
    }
    else
        KeLowerIrql(mSavedIrql);
}
