#include "UserNameFromSIDUtils.h"
#include "drvCommon.h"
#include "StringUtils.h"
#include "KernelHandleGuard.h"

namespace utils
{
/*
	There is two ways how to convert SID to UserName using registry.
	1) Using RID and UserName
	   In kernel registry "\\registry\\machine\\sam\\sam\\domains\\account\\users\\names"
	   Windows store user name in sub key name, in each sub key default value is user RID
	   RID is last element of SubAuthority. 
	   So need to find sub key with default value equal to RID.
	2) Using V-Block parsing
	   In kernel registry "\\registry\\machine\\sam\\sam\\domains\\account\\users"
	   Windows store in each sub key, except "names", exist value with name "V"
	   this is V-Block. V-Block has two important params:
			ULONG NameOffsetFromEnd; at offset 0xc from start
			ULONG NameSizeInBytes;	 at offset 0x10 from start
	   Using this two params SID alsow can be converted to UserName
*/
const wchar_t* namesKeyPath = L"\\registry\\machine\\sam\\sam\\domains\\account\\users\\names";

ULONG GetNameKeyRID(const std::wstring& keyPath)
{
	std::vector<char> buffer(256); 
	ULONG resultLength = NULL;
	PVOID keyInformation = &buffer.front();

	UNICODE_STRING keyPathUnSt = utils::wstring2UnicodeStr(keyPath);

	OBJECT_ATTRIBUTES keyAttr;
	InitializeObjectAttributes(&keyAttr, &keyPathUnSt, OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE, NULL, NULL);

	HANDLE hKey;
	NTSTATUS status = ZwOpenKey(&hKey,GENERIC_READ,&keyAttr);
    if( !NT_SUCCESS(status) )
		throw std::exception("-HideDriver- GetNameKeyRID: ZwOpenKey fail.");

	HandleGuard guard(hKey);

	// RID stores in default value
	ULONG index = 0;
	status = ZwEnumerateValueKey(hKey,
						         index,
								 KeyValueBasicInformation,
								 keyInformation,
								 buffer.size(),
								 &resultLength);
    if( !NT_SUCCESS(status) )
		throw std::exception("-HideDriver- GetNameKeyRID: ZwEnumerateValueKey fail.");

	KEY_VALUE_BASIC_INFORMATION* basicInfo =
		(KEY_VALUE_BASIC_INFORMATION*)keyInformation;

	// MS developers like store values for SAM in type record instead of value record
	return basicInfo->Type;
}
void GetUserNameBySidUseNamesKey(const std::vector<char>& sid,std::wstring* userName)
{
	std::wstring keyPath(namesKeyPath); 
	UNICODE_STRING keyPathUnSt = utils::wstring2UnicodeStr(keyPath);
	
	OBJECT_ATTRIBUTES keyAttr;
	InitializeObjectAttributes(&keyAttr, &keyPathUnSt, OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE, NULL, NULL);

	HANDLE hKey;
	NTSTATUS status = ZwOpenKey(&hKey,GENERIC_READ,&keyAttr);
    if( !NT_SUCCESS(status) )
		throw std::exception("-HideDriver- GetUserNameBySidUseNamesKey: ZwOpenKey fail.");

	HandleGuard guard(hKey);

	SID* pSid = (SID*)&sid.front();
	// RID is last element of SubAuthority
	ULONG ridIndex = pSid->SubAuthorityCount - 1;
	ULONG RID = pSid->SubAuthority[ridIndex];

	if(RID == 0x12)
	{
		// RID of system account always 0x12
		*userName = L"System";
		return;
	}

	std::vector<char> buffer(1024);
	for(ULONG index = 0 ; ; ++index )
	{
		ULONG resultLength = NULL;
		PVOID keyInformation = &buffer.front();
		NTSTATUS status = 
			ZwEnumerateKey(hKey,
						   index,
						   KeyBasicInformation,
						   keyInformation,
						   buffer.size(),
						   &resultLength);
		if(status == STATUS_NO_MORE_ENTRIES)
			break;

    if( !NT_SUCCESS(status) )
			throw std::exception("-HideDriver- GetUserNameBySidUseNamesKey: ZwEnumerateValueKey fail.");

		KEY_BASIC_INFORMATION* keyInfo = 
			(KEY_BASIC_INFORMATION*)keyInformation;

		std::wstring subKeyName(keyInfo->Name,keyInfo->NameLength/2);
		std::wstring subKeyPath = keyPath + L'\\' + subKeyName;
			
		ULONG keyRID = GetNameKeyRID(subKeyPath);
		
		if(keyRID != RID)
			continue;
		
		// Sub key name is user name
		*userName = subKeyName;

		return;
	}
	throw std::exception("-HideDriver- GetUserNameBySidUseNamesKey: Can't find user name for SID.");
}

////////////////////////////////////////////////////////////////////////////////////////////////////

const wchar_t* pathToSubKeysWithVBlock = L"\\registry\\machine\\sam\\sam\\domains\\account\\users\\names";

struct VBlock
{
	ULONG Unknown[3];
	ULONG NameOffsetFromEnd; //0xc
	ULONG NameSizeInBytes;	 //0x10
	ULONG Unknown2[46];
};
char* static_asser[sizeof(VBlock) == 0xcc];

void GetUserNameBySidUseVBlock(const std::vector<char>& sid,std::wstring* userNam)
{
	throw std::exception("GetUserNameBySidUseVBlock - is not implemented yet.");
}

}