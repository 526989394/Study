#pragma once

#include "drvCommon.h"
#include <string>
namespace utils
{
inline UNICODE_STRING 
wstring2UnicodeStr(const std::wstring& str)
{
    UNICODE_STRING uncStr = {str.size()*2,str.size()*2,(PWCHAR)str.c_str()};
    return uncStr;
}
inline UNICODE_STRING 
vector2UnicodeStr(const std::vector<char>& vect)
{
	if(vect.empty())
		throw std::exception("Vector can't be empty");

	UNICODE_STRING uncStr = {vect.size(),vect.size(),(PWCHAR)&vect[0]};
	return uncStr;
}

}