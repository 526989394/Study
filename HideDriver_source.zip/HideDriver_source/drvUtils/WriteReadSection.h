#pragma once

#include "drvCommon.h"
#include "HandleGuardImpl.h"
#include "boost/noncopyable.hpp"

namespace utils
{

class WriteReadSection 
{
    ERESOURCE resource_;
public:
    WriteReadSection();
    ~WriteReadSection();

    void WaitToRead();
    void WaitToWrite();
    void Done();
};

class SectionDoneAction
{
public:
	static void Execute(WriteReadSection* section)
	{
        section->Done();
	}
};
typedef HandleGuardImpl<WriteReadSection*,SectionDoneAction> SectionGuard;

class SectionReadGuard:public SectionGuard
{
public:
	SectionReadGuard(WriteReadSection* section)
		: SectionGuard(section)
	{
		section->WaitToRead();
	}
};

class SectionWriteGuard:public SectionGuard
{
public:
	SectionWriteGuard(WriteReadSection* section)
		: SectionGuard(section)
	{
		section->WaitToWrite();
	}
};

}//namespace utils