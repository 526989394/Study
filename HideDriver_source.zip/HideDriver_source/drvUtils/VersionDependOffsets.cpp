#include "drvCommon.h"
#include "VersionDependOffsets.h"
#include <string>

namespace utils
{

struct SystemVersion
{
	ULONG majorVersion;
	ULONG minorVersion;
};

struct VersionDependOffset
{
	SystemVersion version;
	ULONG offset;
};

VersionDependOffset zwQueryDirSSTOffset[] = 
	{
		{{5,0},0x7D}, // 2k
		{{5,1},0x91}, // XP
		{{5,2},0x97}, // 2k3
		{{6,0},0xDA}, // Vista,2k8
		{{6,1},0xE0}  // Win7
	};

VersionDependOffset zwQuerySysInfoSSTOffset[] = 
	{
		{{5,0},0x97}, // 2k
		{{5,1},0xAD}, // XP
		{{5,2},0xB5}, // 2k3
		{{6,0},0xF8}, // Vista,2k8
		{{6,1},0x106} // Win7
	};

struct SSTOffset
{
	wchar_t* name;
	VersionDependOffset* offsetArray;
	size_t arraySize;
};

SSTOffset sstOffsetArray[] = 
	{
		{	L"ZwQueryDirectoryFile", 
			zwQueryDirSSTOffset,
			sizeof(zwQueryDirSSTOffset)
		},
		{	L"ZwQuerySystemInformation", 
			zwQuerySysInfoSSTOffset,
			sizeof(zwQueryDirSSTOffset)
		}
	};

ULONG GetOffsetImpl(VersionDependOffset* offsetsArray,
					size_t size,
					ULONG majorVersion,
					ULONG minorVersion)
{

	for( size_t i = 0; i < size ; ++i)
	{
		if( offsetsArray[i].version.majorVersion != majorVersion )
			continue;

		if( offsetsArray[i].version.minorVersion != minorVersion )
			continue;
	
		return offsetsArray[i].offset;
	}

	throw std::exception(__FUNCTION__" Can't find offset.");
}

ULONG GetSSTOffsetImpl(VersionDependOffset* offsetsArray,
					   size_t size)
{
	ULONG majorVersion,minorVersion;
	PsGetVersion(&majorVersion,&minorVersion,NULL,NULL);

	return GetOffsetImpl(offsetsArray,size,
						 majorVersion,minorVersion);	
}

ULONG GetSSTZwQueryDirOffset()
{
	return GetSSTOffsetImpl(zwQueryDirSSTOffset,
							sizeof(zwQueryDirSSTOffset));
}

ULONG GetSSTZwQuerySysInfoOffset()
{
	return GetSSTOffsetImpl(zwQuerySysInfoSSTOffset,
							sizeof(zwQuerySysInfoSSTOffset));
}

ULONG GetSSTOffsetByName(wchar_t* name,size_t size)
{
	for( size_t i = 0; i < sizeof(sstOffsetArray) ; ++i )
	{
		if( wcslen(sstOffsetArray[i].name) != size)
			continue;

		if( memcmp(sstOffsetArray[i].name,name,size) != 0)
			continue;

		return GetSSTOffsetImpl(sstOffsetArray[i].offsetArray,
								sstOffsetArray[i].arraySize);
	}

	throw std::exception(__FUNCTION__" Can't find offset info in sstOffsetArray");
}
}// namespace utils