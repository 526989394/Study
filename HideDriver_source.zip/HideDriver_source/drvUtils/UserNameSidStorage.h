#pragma once

#include "drvCommon.h"
#include "WriteReadSection.h"

#include <string>
#include <vector>
#include <map>

namespace utils
{
typedef std::wstring UserName;
typedef std::vector<char> UserSid;

class UserNameSidStorage
{
	typedef std::map<UserSid,UserName> SidNameMap;
	
	SidNameMap nameSidMap_;
	utils::WriteReadSection mapLock_;
public:
	UserNameSidStorage()
	{}

	void GetUserNameBySid(const UserSid& sid, UserName* userName);

private:
	UserName UserNameSidStorage::RequestNewRecord(const UserSid& sid);
};

}