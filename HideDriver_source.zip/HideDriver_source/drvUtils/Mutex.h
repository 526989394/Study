#pragma once

#include "drvCommon.h"
#include "KernelHandleGuard.h"
#include <boost/noncopyable.hpp>
#include <memory>

namespace utils
{
class Mutex: public boost::noncopyable
{
    std::auto_ptr<KMUTEX> mutex_;
public:
    Mutex()
        : mutex_(new KMUTEX)
    {
        KeInitializeMutex(mutex_.get(), 0);
    }
    void enter()
    {
        NTSTATUS status = 
            KeWaitForMutexObject( mutex_.get()
                                , Executive
                                , KernelMode
                                , FALSE
                                , NULL );
        if( status != STATUS_SUCCESS )
            throw std::exception(__FUNCTION__" fail.");
    }
    void leave()
    {
        KeReleaseMutex(mutex_.get(), FALSE);
    }
};

class MutexLeaveAction
{
public:
	static void Execute(Mutex* mutex)
	{
		mutex->leave();
	}
};
typedef HandleGuardImpl<Mutex*,MutexLeaveAction> MutexGuard;

class AutoMutex:public MutexGuard
{
public:
	AutoMutex(Mutex* mutex)
		: MutexGuard(mutex)
	{
		mutex->enter();
	}
};

}