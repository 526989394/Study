#include "ServiceTableDef.h"
#include "VersionDependOffsets.h"

namespace utils
{

const UCHAR opcode_MovEax = 0xB8; // __asm move eax,Value

inline ULONG GetFunctionSSTIndex(PUNICODE_STRING function_name)
{
    /*    
    All ZwXXX functions exported by NTOSKRNL.exe start with :
    
        mov eax, ULONG 
    
    where ULONG is the NtXXX function index in SST
    */

	// Be careful with function MmGetSystemRoutineAddress, under 
	// Windows XP(SP2) and lower this function throw SEH exception if 
	// they�re passed an invalid system routine name.
	// Using __try/__except block is not good solution since SEH 
	// is not a formal contract for this API, so is not guarantees 
	// that the OS is still in a stable state after you have caught 
	// the exception.
	PVOID pTrueFuncPtr_ZW = MmGetSystemRoutineAddress(function_name);
 
    if(pTrueFuncPtr_ZW == NULL)
        throw std::exception(__FUNCTION__" Can't get function address.");

	// Check command byte for valid opcode
	// Starts from Vista DriverVerifier can substitute ntoskrnl code.
	if( *( (PUCHAR)pTrueFuncPtr_ZW ) != opcode_MovEax )
		throw std::exception(__FUNCTION__" Function address points to supposititious code.");

    // Skip command byte, move to index byte
    ULONG funcIndex = *(PULONG)((PUCHAR) pTrueFuncPtr_ZW + 1);
    
    if( funcIndex == NULL)    
        throw std::exception(__FUNCTION__" Can't get function SST index");

	return funcIndex;
}
inline PVOID GetFunctionSSTPtr(ULONG fncIndex)
{
	PNTPROC ServiceTable=pNtoskrnl->ServiceTable;

	ULONG TotalCount = pNtoskrnl->ServiceLimit;
	if( fncIndex > TotalCount ) 
		throw std::exception(__FUNCTION__" Wrong SST index");
	
	return ServiceTable[fncIndex];
}
inline PVOID GetFunctionSSTPtr(PUNICODE_STRING function_name)
{
	return GetFunctionSSTPtr( GetFunctionSSTIndex(function_name) );
}
inline PVOID GetFunctionSSTPtrEx(PUNICODE_STRING function_name)
{
	ULONG fncIndex;
	try 
	{
		fncIndex = utils::GetFunctionSSTIndex(function_name);
	}
	catch(const std::exception&)
	{
		// Use predefined offsets
		fncIndex = utils::GetSSTOffsetByName(function_name->Buffer,function_name->Length/2);		
	}
	return utils::GetFunctionSSTPtr(fncIndex);
}
}