#include "drvCommon.h"
#include "AccessUtils.h"
#include "UserNameFromSIDUtils.h"
#include "stdlib.h" // for use mbstowcs()
#include "KernelHandleGuard.h"
#include "StringUtils.h"
#include "VersionDependOffsets.h"
#include "VersionIndependOffsets.h"

#include "scoped_action.h"
#include "boost/bind.hpp"

namespace utils
{
void GetProcessImagePath(PEPROCESS proc,std::wstring* imagePath)
{
	HANDLE hProc;
	NTSTATUS status = 
		ObOpenObjectByPointer(proc,OBJ_KERNEL_HANDLE,0,0,NULL,KernelMode,&hProc);
	if( !NT_SUCCESS(status) )
		throw std::exception("Can't open file");

	HandleGuard guard(hProc);

	// Get name size
	ULONG retLength;
	status = ZwQueryInformationProcess(hProc,ProcessImageFileName,NULL,0,&retLength);
	if( status != STATUS_INFO_LENGTH_MISMATCH)
		throw std::exception(__FUNCTION__"Can't get process image file name size.");

	std::vector<char> buffer(retLength+2);

	// Get name
	status = ZwQueryInformationProcess(hProc,ProcessImageFileName,&buffer[0],buffer.size(),&retLength);
	if( !NT_SUCCESS(status) )
		throw std::exception(__FUNCTION__"Can't get process image file name.");
	
	PUNICODE_STRING imageFileNameUs = (PUNICODE_STRING)&buffer[0];

	*imagePath = std::wstring(imageFileNameUs->Buffer,imageFileNameUs->Length/2);
}
void GetCurrentProcessImagePath(std::wstring* imagePath)
{
	GetProcessImagePath(PsGetCurrentProcess(),imagePath);
}
void GetCurrentProcessNameFull(std::wstring* processName)
{
	std::wstring imagePath;
	GetCurrentProcessImagePath(&imagePath);
	if(imagePath.size() == 0)
		return;

	size_t nameseparator = imagePath.rfind(L'\\');
	if(nameseparator != 0)
		*processName = std::wstring(&imagePath.at(nameseparator + 1));
	else
		*processName = imagePath;
}
void GetCurrentProcessName16(std::wstring* processName)
{
	PEPROCESS ProcInfo = PsGetCurrentProcess();
	ULONG nameOffset   = utils::GetEprocessNameOffset();

	char* imageFileName = (char*)ProcInfo + nameOffset;

	WCHAR wszImageFileName[16];
	mbstowcs(wszImageFileName,imageFileName,16);
	
	*processName = std::wstring(wszImageFileName);
}
void GetCurrentProcessName(std::wstring* processName)
{
	GetCurrentProcessName16(processName);
	if( (processName->size() == 15) || processName->empty() )
	{
		// This mean that image name is has maximum size
		// Need to get full image name if name size greater then 16 bytes
		
		*processName = L"";
		GetCurrentProcessNameFull(processName);
	}
}
void GetCurrentUserSid(std::vector<char>* sid)
{
	SECURITY_SUBJECT_CONTEXT Context;
	PACCESS_TOKEN pAccessToken;    
	PTOKEN_USER pToken;
	
	SeCaptureSubjectContext(&Context);
	utils::scoped_action guard(boost::bind(&SeReleaseSubjectContext,&Context));

	pAccessToken  = SeQuerySubjectContextToken(&Context); 
	
	NTSTATUS status = SeQueryInformationToken(pAccessToken,TokenUser,(PVOID*)&pToken);
	if( status != STATUS_SUCCESS)    
		throw std::exception("-HideDriver- ERROR: SeQueryInformationToken fail.\n");

	if ( RtlValidSid(pToken->User.Sid) != TRUE )
		throw std::exception("-HideDriver- ERROR: SeQueryInformationToken return invalid SID.\n");
		
	ULONG dwSidLengthReal = RtlLengthSid(pToken->User.Sid);
	
	sid->resize(dwSidLengthReal);
	RtlCopySid(dwSidLengthReal, &sid->front(), pToken->User.Sid);
}

void GetUserNameBySid(const std::vector<char>& sid,std::wstring* userName)
{
	try
	{
		GetUserNameBySidUseNamesKey(sid,userName);
		return;
	}
	catch(const std::exception& ex)
	{
		DbgPrint("-HideDriver- GetUserNameBySid std::exception: %s",ex.what());
	}

	// If you reach this block this mean that GetUserNameBySidUseNamesKey
	// not always work fine, you should implement function GetUserNameBySidUseVBlock
	// logic the same.

	throw std::exception("GetUserNameBySidUseNamesKey fail. Another method not implemented yet.");
	//GetUserNameBySidUseVBlock(sid,userName);
}

}//namespace utils