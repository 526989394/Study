#include "drvCommon.h"
#include "VersionInDependOffsets.h"

namespace utils
{

#define SYSNAME    "System"

ULONG gEprocessNameOffset = NULL;

void InitOffsets()
{
    PEPROCESS curproc = PsGetCurrentProcess();

    //
    // Scan for 12KB, hoping the KPEB never grows that big!
    //
    for( int i = 0; i < 3*PAGE_SIZE; i++ ) 
    {
        if( !strncmp( SYSNAME, (PCHAR) curproc + i, sizeof(SYSNAME) )) 
        {
            gEprocessNameOffset = i;
            return;
        }
    }

    //
    // Name not found - oh, well
    //
    throw std::exception("Can't find name offset inside EPROCESS");
}

ULONG GetEprocessNameOffset()
{
    return gEprocessNameOffset;
}

}
