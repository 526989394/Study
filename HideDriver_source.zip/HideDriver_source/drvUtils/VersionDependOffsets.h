#pragma once

namespace utils
{

ULONG GetSSTOffsetByName(wchar_t* name,size_t size);

ULONG GetSSTZwQueryDirOffset();
ULONG GetSSTZwQuerySysInfoOffset();

}