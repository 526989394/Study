#include "WriteReadSection.h"

namespace utils
{

WriteReadSection::WriteReadSection()
{
    NTSTATUS status = ExInitializeResourceLite(&resource_);
    if( !NT_SUCCESS(status) )
        throw std::exception(__FUNCTION__" ExInitializeResourceLite fail.");
}

WriteReadSection::~WriteReadSection()
{
    NTSTATUS status = ExDeleteResourceLite(&resource_);
    if( !NT_SUCCESS(status) )
        throw std::exception(__FUNCTION__" ExDeleteResourceLite fail.");
}

void WriteReadSection::WaitToRead()
{
    KeEnterCriticalRegion();
    ExAcquireResourceSharedLite(&resource_,TRUE);
}

void WriteReadSection::WaitToWrite()
{
    KeEnterCriticalRegion();
    ExAcquireResourceExclusiveLite(&resource_,TRUE);
}

void WriteReadSection::Done()
{
    ExReleaseResourceLite(&resource_);
    KeLeaveCriticalRegion();
}

}//namespace utils