#pragma once

#include "drvCommon.h"
#include "WriteReadSection.h"

#include <list>
#include <map>

namespace utils
{
struct IQueryDispatcher
{
    virtual void Dispatch(ULONG controlCode,
						  WCHAR* buf,
						  ULONG inputBufSize,
						  ULONG outputBufSize,
						  ULONG* bytesTxd)=0;
};
class QueryMng
{
    typedef std::list<IQueryDispatcher*> DispatchList; 
    typedef std::map<ULONG,DispatchList> DispatchMap;
    DispatchMap dispatchMap_;

    utils::WriteReadSection mapLock_;
public:
    NTSTATUS ProcessIrp(PIRP irp);
    void Subscribe(ULONG controlCode,IQueryDispatcher* dispatcher);
    void UnSubscribe(ULONG controlCode,IQueryDispatcher* dispatcher);

private:
    void CallDispatchers(ULONG controlCode,
						 WCHAR* buf,
						 ULONG inputBufSize,
						 ULONG outputBufSize,
						 ULONG* bytesTxd);
};
}