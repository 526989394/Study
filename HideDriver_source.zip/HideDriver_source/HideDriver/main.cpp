#include "drvCommon.h"
#include "IRPUtils.h"
#include "Ioctl.h"

#include "QueryMng.h"
#include "HookMng.h"
#include "FileHider.h"
#include "ProcessHider.h"
#include "VersionIndependOffsets.h"

////////////////////////////////////////////////////////////////////////////////////

/*Name and symbolic link need to provide access to driver from User Mode*/
//The name of current driver
UNICODE_STRING gDeviceName;
PCWSTR gDeviceNameStr       = L"\\Device\\HideDriver";
//The symbolic link of driver location
UNICODE_STRING gSymbolicLinkName;
PCWSTR gSymbolicLinkNameStr = L"\\DosDevices\\HideDriver";

//The object associated with the driver
PDEVICE_OBJECT gDeviceObject = NULL;

/*QueryMng used for dispatching IOCTL queries*/
utils::QueryMng gQueryMng;
/*HookMng used for hooking SST(System Service Table)*/
HideDriver::HookMng     gHookMng;
/*FileHider used for hiding files and folders*/
HideDriver::FileHider gFileHider;
/*ProcessHider used for hiding process*/
HideDriver::ProcessHider gProcessHider;

////////////////////////////////////////////////////////////////////////////////////

extern "C" 
NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,IN PUNICODE_STRING RegistryPath);

VOID     DriverUnload(IN PDRIVER_OBJECT DriverObject);
NTSTATUS DeviceControlRoutine( IN PDEVICE_OBJECT fdo, IN PIRP Irp );
NTSTATUS DeviceCloseHandleRoutine(IN PDEVICE_OBJECT fdo,IN PIRP Irp);
NTSTATUS DeviceOpenHandleRoutine(IN PDEVICE_OBJECT fdo,IN PIRP Irp);
NTSTATUS Initialize();
VOID     Uninitialize();

////////////////////////////////////////////////////////////////////////////////////

NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,
                     IN PUNICODE_STRING RegistryPath)
{
    DbgPrint("\t------HIDE DRIVER START------\n");

    libcpp_init();

    /* Start Driver initialization */

    RtlInitUnicodeString(&gDeviceName,       gDeviceNameStr);
    RtlInitUnicodeString(&gSymbolicLinkName, gSymbolicLinkNameStr);

    NTSTATUS status;
    status = IoCreateDevice(DriverObject,     // pointer on DriverObject
                            0,                // additional size of memory, for device extension
                            &gDeviceName,     // pointer to UNICODE_STRING
                            FILE_DEVICE_NULL, // Device type
                            0,                // Device characteristic
                            FALSE,            // "Exclusive" device
                            &gDeviceObject);  // pointer do device object
    if (status != STATUS_SUCCESS)
        return STATUS_FAILED_DRIVER_ENTRY;

    status = IoCreateSymbolicLink(&gSymbolicLinkName,&gDeviceName);
    if (status != STATUS_SUCCESS)
        return STATUS_FAILED_DRIVER_ENTRY;

    // Register IRP handlers
    PDRIVER_DISPATCH *mj_func;
    mj_func = DriverObject->MajorFunction;
    DriverObject->DriverUnload = DriverUnload;

    mj_func[IRP_MJ_DEVICE_CONTROL] = DeviceControlRoutine;
    mj_func[IRP_MJ_CREATE]           = DeviceOpenHandleRoutine;
    mj_func[IRP_MJ_CLOSE]           = DeviceCloseHandleRoutine;

    /* Driver initialization are done */
    return Initialize();
}
VOID DriverUnload(IN PDRIVER_OBJECT DriverObject)
{    
    Uninitialize();

    IoDeleteSymbolicLink(&gSymbolicLinkName);
    IoDeleteDevice(gDeviceObject);

    libcpp_exit();

    DbgPrint("\t------HIDE DRIVER EXIT------\n");
    
    return;
}
NTSTATUS Initialize()
{
    try
    {
        utils::InitOffsets();

        gFileHider.Initialize(gHookMng,gQueryMng);
		gProcessHider.Initialize(gHookMng,gQueryMng);
    }
    catch(const std::exception& ex)
    {
		DbgPrint("-HideDriver- Initialize() std::exception: %s\n",ex.what());
        return STATUS_FAILED_DRIVER_ENTRY;
    }
    return STATUS_SUCCESS;
}
VOID Uninitialize()
{
    try
    {
        gFileHider.Cleanup(gHookMng,gQueryMng);
		gProcessHider.Cleanup(gHookMng,gQueryMng);
    }
    catch(const std::exception& ex)
    {
		DbgPrint("-HideDriver- Uninitialize() std::exception: %s\n",ex.what());
	}
}
NTSTATUS DeviceControlRoutine( IN PDEVICE_OBJECT fdo, IN PIRP pIrp )
{
    /*
    * Query manager process all IRP.
    * IRP will be completed by Query manager.        
    */
    return gQueryMng.ProcessIrp(pIrp);    
}
// DeviceOpenHandleRoutine: process IRP_MJ_CREATE call.
NTSTATUS DeviceOpenHandleRoutine(IN PDEVICE_OBJECT fdo,IN PIRP Irp)
{
    DbgPrint("-HideDriver- IRP_MJ_CREATE\n");

    return utils::CompleteIrp(Irp,STATUS_SUCCESS,0);
}
// DeviceCloseHandleRoutine: process IRP_MJ_CLOSE call.
NTSTATUS DeviceCloseHandleRoutine(IN PDEVICE_OBJECT fdo,IN PIRP Irp)
{
    DbgPrint("-HideDriver- IRP_MJ_CLOSE\n");

    return utils::CompleteIrp(Irp,STATUS_SUCCESS,0);
}