#include "HookFactory.h"
#include "ServiceTableUtils.h"

namespace HideDriver
{
SSTHook CreateSSTHook(const PVOID pNewFuncPtr,PUNICODE_STRING function_name)
{
	ULONG fncIndex;
	try 
	{
		fncIndex = utils::GetFunctionSSTIndex(function_name);
	}
	catch(const std::exception&)
	{
		// Use predefined offsets
		fncIndex = utils::GetSSTOffsetByName(function_name->Buffer,function_name->Length/2);		
	}
	PVOID fncPtr = utils::GetFunctionSSTPtr(fncIndex);

	SSTHook mNewHook = {fncIndex,pNewFuncPtr,fncPtr};

	return mNewHook;
}
}//namespace HideDriver