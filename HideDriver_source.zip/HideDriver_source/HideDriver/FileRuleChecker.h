#pragma once

#include "RuleChecker.h"
#include "IFileChecker.h"

namespace HideDriver
{
class FileRuleChecker 
{
	RuleChecker ruleChecker_;
public:
	FileRuleChecker(IRuleHolder* ruleHolder)
		: ruleChecker_(ruleHolder)
	{}

	bool CheckFile(wchar_t* nameToCheck,
				   size_t nameSize,
				   const HideAlgorithm::NtQueryDirParams& params);

};
}