#include "RuleChecker.h"
#include "AccessUtils.h"
#include "WildCards.h"

#include "UserNameSidStorage.h"

#include "scoped_action.h"
#include "boost/bind.hpp"

namespace HideDriver
{
utils::UserNameSidStorage gUserSidStorage;

bool RuleChecker::CheckProcessAccess(const WStringList& procList)
{
	std::wstring curProcName;
	utils::GetCurrentProcessName(&curProcName);
    
	WStringList::const_iterator it = procList.begin();
	for( ; it != procList.end() ; ++it)
	{
		if( utils::ApplyWildCards(*it,curProcName) )
			return true;
	}

	return false;
}

bool RuleChecker::CheckUserAccess(const WStringList& userList)
{
	std::vector<char> curUserSid;
	utils::GetCurrentUserSid(&curUserSid);
	
	std::wstring curUserName;
	gUserSidStorage.GetUserNameBySid(curUserSid,&curUserName);

	WStringList::const_iterator it = userList.begin();
	for( ; it != userList.end() ; ++it)
	{
		if( utils::ApplyWildCards(*it,curUserName) )
			return true;
	}

	return false;
}

bool RuleChecker::CheckRules(NameChecker nameChecker)
{
    const HideRuleList& hideRuleList = ruleHolder_->AcquireRuleList();
    utils::scoped_action guard(boost::bind(&IRuleHolder::ReleaseRuleList,ruleHolder_));

    HideRuleList::const_iterator it = hideRuleList.begin();
    for( ; it != hideRuleList.end() ; ++it )
    {
        if( !nameChecker(it->objectName) )
            continue;

        if( !CheckProcessAccess(it->processList) )
            continue;

        if( !CheckUserAccess(it->userList) )
            continue;

        return true;
    }
    return false;
}

}