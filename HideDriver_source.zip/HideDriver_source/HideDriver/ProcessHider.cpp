#include "ProcessHider.h"

#include "drvCommon.h"
#include "QueryMng.h"
#include "HookMng.h"
#include "IProcessChecker.h"
#include "RuleHolder.h"
#include "ProcessHook.h"
#include "ProcessRuleChecker.h"
#include "UserCommunication.h"

namespace HideDriver
{

class ProcessHiderImpl:public HideAlgorithm::IProcessChecker
{  
	RuleHolder ruleHolder;

    ProcessHook hook_;
    ProcessRuleChecker ruleChecker_;
    ProcessCommunication userComm_;
public:
    ProcessHiderImpl()
        : hook_(this)
        , ruleChecker_(&ruleHolder)
        , userComm_(&ruleHolder)
    {}

    void Initialize(HookMng& hookMng,utils::QueryMng& queryMng)
	{
		hook_.Initialize(hookMng);
		userComm_.Initialize(queryMng);
	}
    void Cleanup(HookMng& hookMng,utils::QueryMng& queryMng)
	{
		hook_.Cleanup(hookMng);
		userComm_.Cleanup(queryMng);
	}

    bool CheckProcess( wchar_t* imageName
					 , size_t nameSize)
	{
		return ruleChecker_.CheckProcess(imageName,nameSize);
	}
};

struct ProcessHider::ProcessHiderImpl: public HideDriver::ProcessHiderImpl
{};

ProcessHider::ProcessHider()
{
    pImpl = new ProcessHider::ProcessHiderImpl();
}
ProcessHider::~ProcessHider()
{
    delete pImpl;
}

void ProcessHider::Initialize(HookMng& hookMng,utils::QueryMng& queryMng)
{
    pImpl->Initialize(hookMng,queryMng);
}
void ProcessHider::Cleanup(HookMng& hookMng,utils::QueryMng& queryMng)
{
    pImpl->Cleanup(hookMng,queryMng);
}

}