#include "RuleHolder.h"
#include "KernelHandleGuard.h"

#include <algorithm>

namespace HideDriver
{

const HideRuleList& RuleHolder::AcquireRuleList()
{
    listLock_.WaitToRead();
    return hideRuleList_;
}
void RuleHolder::ReleaseRuleList()
{
    listLock_.Done();
}

void RuleHolder::AddRule(const HideRule& rule)
{
    utils::SectionWriteGuard guard(&listLock_);
    hideRuleList_.push_back(rule);
}

void RuleHolder::DelRule(const HideRule& rule)
{
    utils::SectionWriteGuard guard(&listLock_);
    
    HideRuleList::iterator it = 
        std::find(hideRuleList_.begin(),hideRuleList_.end(),rule);

    if( it == hideRuleList_.end())
        throw std::exception("Can't delete rule - rule not exist.");

    hideRuleList_.erase(it);
}

void RuleHolder::DelAllRules()
{
    utils::SectionWriteGuard guard(&listLock_);
    hideRuleList_.clear();
}

}//namespace HideDriver