#pragma once

#include "IRuleHolder.h"
#include "QueryMng.h"

namespace HideDriver
{

class RuleProcessor
{
    IRuleHolderEx* ruleHolder_;
public:
    RuleProcessor(IRuleHolderEx* ruleHolder)
        :ruleHolder_(ruleHolder)
    {}

    void AddRule(WCHAR* pBuf,ULONG buf_size);
    void DelRule(WCHAR* pBuf,ULONG buf_size);
    void DelAllRules();
    void QueryRules(WCHAR* pBuf,ULONG outputBufSize,ULONG* bytesTxd);
private:
	void QueryRulesImpl(WCHAR* pBuf,ULONG buf_size,ULONG* bytesTxd);
};

class FileCommunication:public utils::IQueryDispatcher
{
    RuleProcessor ruleProcessor_;
public:
    FileCommunication(IRuleHolderEx* ruleHolder)
        :ruleProcessor_(ruleHolder)
    {}

    void Initialize(utils::QueryMng& queryMng);
    void Cleanup(utils::QueryMng& queryMng);

    void Dispatch(ULONG controlCode,
				  WCHAR* buf,
				  ULONG inputBufSize,
				  ULONG outputBufSize,
				  ULONG* bytesTxd);
};

class ProcessCommunication:public utils::IQueryDispatcher
{
    RuleProcessor ruleProcessor_;
public:
    ProcessCommunication(IRuleHolderEx* ruleHolder)
        :ruleProcessor_(ruleHolder)
    {}

    void Initialize(utils::QueryMng& queryMng);
    void Cleanup(utils::QueryMng& queryMng);

    void Dispatch(ULONG controlCode,
				  WCHAR* buf,
				  ULONG inputBufSize,
				  ULONG outputBufSize,
				  ULONG* bytesTxd);
};

}