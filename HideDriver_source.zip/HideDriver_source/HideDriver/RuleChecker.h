#pragma once

#include "IRuleHolder.h"
#include <boost/function.hpp>
namespace HideDriver
{
typedef boost::function<bool(const std::wstring&)> NameChecker;
class RuleChecker
{
    IRuleHolder* ruleHolder_;
public:
    RuleChecker(IRuleHolder* ruleHolder)
        : ruleHolder_(ruleHolder)
    {}
    bool CheckRules(NameChecker nameChecker);

private:
    bool CheckProcessAccess(const WStringList& processList);
    bool CheckUserAccess(const WStringList& userList);
};

}