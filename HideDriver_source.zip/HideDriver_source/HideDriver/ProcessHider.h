#pragma once

#include "HookMng.h"
#include "QueryMng.h"

namespace HideDriver
{

class ProcessHider
{
    class ProcessHiderImpl;
    ProcessHiderImpl* pImpl;
public:
    ProcessHider();
    ~ProcessHider();

    void Initialize(HookMng& hookMng,utils::QueryMng& queryMng);
    void Cleanup(HookMng& hookMng,utils::QueryMng& queryMng);
};

}//namespace HideDriver