#pragma once

#include "drvCommon.h"

namespace HideDriver
{

struct SSTHook
{
    ULONG Index_SST;
    PVOID newFuncPtr;
    PVOID trueFuncPtr;

    // STL algorithms support
    bool operator==(const SSTHook& _Right) const
    {    
        return (Index_SST == _Right.Index_SST)
             &&(newFuncPtr == _Right.newFuncPtr)
             &&(trueFuncPtr == _Right.trueFuncPtr);
    }
    bool operator!=(const SSTHook& _Right) const
    {    
        return (!(*this == _Right));
    }
};

SSTHook CreateSSTHook(PVOID pNewFuncPtr,PUNICODE_STRING function_name);

}// namespace HideDriver