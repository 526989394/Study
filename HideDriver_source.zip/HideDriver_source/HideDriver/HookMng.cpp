#include "HookMng.h"
#include "ServiceTableDef.h"

#include <algorithm>
#include <boost/bind.hpp>

namespace HideDriver
{
/* Function for working with WriteProtect bit */
ULONG ClearWPBit()
{
    ULONG CR0Reg;
    __asm                                       
    {                                           
        mov eax, cr0                            
        mov CR0Reg,eax       /*save WP bit*/      
        and eax,0xFFFEFFFF /*clear WP bit*/     
        mov cr0, eax                            
    }
    return CR0Reg;
}

void SetWPBit(ULONG CR0Reg)
{
    __asm                                       
    {                                           
        mov eax, CR0Reg                         
        mov cr0, eax      /*restore WP bit*/                        
    }
}
void HookMng::AplyHook(const SSTHook& hook)
{
    KIRQL oldIrql;
    KeRaiseIrql(HIGH_LEVEL,&oldIrql); // Catch single processor

    ULONG CR0Reg = ClearWPBit();

    //InterlockedExchangePointer(&ServiceTable[hook.Index_SST],hook.newFuncPtr);
    ServiceTable[hook.Index_SST] = hook.newFuncPtr;

    SetWPBit(CR0Reg);

    KeLowerIrql(oldIrql); // Free processor
}

void HookMng::AddHook(const SSTHook& hook)
{
    utils::AutoMutex guard(&listLock_);
    
    HookList::const_iterator it =
        std::find(hookList_.begin(),hookList_.end(),hook);

    if( it != hookList_.end())
        throw std::exception(__FUNCTION__"SSTHook already added.");

    hookList_.push_back(hook);

    AplyHook(hook);
}

void HookMng::DeleteImpl(const SSTHook& hook)
{
    HookList::iterator it =
        std::find(hookList_.begin(),hookList_.end(),hook);

    if( it == hookList_.end())
        throw std::exception(__FUNCTION__"Can't find hook.");

    hookList_.erase(it);

    SSTHook reverseHook = hook;
    reverseHook.newFuncPtr = reverseHook.trueFuncPtr;

    AplyHook(reverseHook);
}
void HookMng::DeleteHook(const SSTHook& hook)
{
    utils::AutoMutex guard(&listLock_);

    DeleteImpl(hook);
}
void HookMng::SafeDeleteHook(const SSTHook& hook)
{
    // Check if someone hooked over our hook
    if( ServiceTable[hook.Index_SST] != hook.newFuncPtr)
        throw std::exception(__FUNCTION__"Someone hooked SST over our hook");

    DeleteHook(hook);
}
void HookMng::DeleteAllHooks(const SSTHook& hook)
{
    utils::AutoMutex guard(&listLock_);

    HookList hookListCopy = hookList_;
    std::for_each(hookListCopy.begin(),
                  hookListCopy.end(),
                  boost::bind(&HookMng::DeleteImpl,this,_1));
}

}//namespace HideDriver