#pragma once

#include "WriteReadSection.h"
#include <list>
#include <string>

namespace HideDriver
{
typedef std::list<std::wstring> WStringList;
struct HideRule
{
    std::wstring objectName;
    WStringList processList;
	WStringList userList;

    // STL algorithms support
    bool operator==(const HideRule& _Right) const
    {    
        return (objectName == _Right.objectName)
            && (processList == _Right.processList)
            && (userList == _Right.userList);
    }
    bool operator!=(const HideRule& _Right) const
    {    
        return (!(*this == _Right));
    }
};
typedef std::list<HideRule> HideRuleList;

struct IRuleHolder
{
    virtual const HideRuleList& AcquireRuleList()=0; 
    virtual void ReleaseRuleList()=0; 
};
struct IRuleHolderEx:public IRuleHolder
{
    virtual void AddRule(const HideRule& rule)=0;
    virtual void DelRule(const HideRule& rule)=0;
    virtual void DelAllRules()=0;
};
}