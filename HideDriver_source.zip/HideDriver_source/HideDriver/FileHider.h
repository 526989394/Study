#pragma once

#include "HookMng.h"
#include "QueryMng.h"

namespace HideDriver
{

class FileHider
{
    class FileHiderImpl;
    FileHiderImpl* pImpl;
public:
    FileHider();
    ~FileHider();

	void Initialize(HookMng& hookMng,utils::QueryMng& queryMng);
    void Cleanup(HookMng& hookMng,utils::QueryMng& queryMng);
};

}//namespace HideDriver