#pragma once

#include "HookMng.h"
#include "IFileChecker.h"

namespace HideDriver
{

class FileHook
{
    SSTHook hook_;

public:
	FileHook(HideAlgorithm::IFileChecker* fileChecker);

    void Initialize(HookMng& refHookMng);
    void Cleanup(HookMng& refHookMng);
};

}//namespace HideDriver