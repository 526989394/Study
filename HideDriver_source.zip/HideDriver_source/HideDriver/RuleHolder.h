#pragma once

#include "drvCommon.h"
#include "IRuleHolder.h"
#include "WriteReadSection.h"

namespace HideDriver
{
class RuleHolder:public IRuleHolderEx
{  
    HideRuleList hideRuleList_;

    utils::WriteReadSection listLock_;
public:
    const HideRuleList& AcquireRuleList(); 
    void ReleaseRuleList(); 

    void AddRule(const HideRule& rule);
    void DelRule(const HideRule& rule);
    void DelAllRules();
};
}