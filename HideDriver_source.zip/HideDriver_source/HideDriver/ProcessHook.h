#pragma once

#include "HookMng.h"
#include "IProcessChecker.h"

namespace HideDriver
{

class ProcessHook
{
    SSTHook hook_;

public:
	ProcessHook(HideAlgorithm::IProcessChecker* processChecker);

    void Initialize(HookMng& refHookMng);
    void Cleanup(HookMng& refHookMng);
};

}//namespace HideDriver