#include "FileHider.h"

#include "drvCommon.h"
#include "QueryMng.h"
#include "HookMng.h"
#include "IFileChecker.h"
#include "RuleHolder.h"
#include "FileHook.h"
#include "FileRuleChecker.h"
#include "UserCommunication.h"

namespace HideDriver
{

class FileHiderImpl:public HideAlgorithm::IFileChecker
{  
	RuleHolder ruleHolder;

    FileHook hook_;
    FileRuleChecker ruleChecker_;
    FileCommunication userComm_;
public:
    FileHiderImpl()
        : hook_(this)
        , ruleChecker_(&ruleHolder)
        , userComm_(&ruleHolder)
    {}

    void Initialize(HookMng& hookMng,utils::QueryMng& queryMng)
	{
		hook_.Initialize(hookMng);
		userComm_.Initialize(queryMng);
	}
    void Cleanup(HookMng& hookMng,utils::QueryMng& queryMng)
	{
		hook_.Cleanup(hookMng);
		userComm_.Cleanup(queryMng);
	}

    bool CheckFile( wchar_t* fileName
                  , size_t nameSize
                  , const HideAlgorithm::NtQueryDirParams& params )
	{
		return ruleChecker_.CheckFile(fileName,nameSize,params);
	}
};

struct FileHider::FileHiderImpl: public HideDriver::FileHiderImpl
{};

FileHider::FileHider()
{
    pImpl = new FileHider::FileHiderImpl();
}
FileHider::~FileHider()
{
    delete pImpl;
}

void FileHider::Initialize(HookMng& hookMng,utils::QueryMng& queryMng)
{
    pImpl->Initialize(hookMng,queryMng);
}
void FileHider::Cleanup(HookMng& hookMng,utils::QueryMng& queryMng)
{
    pImpl->Cleanup(hookMng,queryMng);
}

}