#pragma once

#include "drvCommon.h"
#include "HookFactory.h"
#include "Mutex.h"

#include <list>

namespace HideDriver
{
class HookMng
{
private:
    typedef std::list<SSTHook> HookList;
    HookList hookList_;
    
    utils::Mutex listLock_;
public:
    void AddHook(const SSTHook& hook);
    void DeleteHook(const SSTHook& hook);
    void SafeDeleteHook(const SSTHook& hook);
    void DeleteAllHooks(const SSTHook& hook);

private:
    void DeleteImpl(const SSTHook& hook);
    void AplyHook(const SSTHook& hook);
};
}
