#pragma once

#include "RuleChecker.h"
#include "WildCards.h"

#include <boost/bind.hpp>

namespace HideDriver
{
class ProcessRuleChecker
{
	RuleChecker ruleChecker_;
public:
	ProcessRuleChecker(IRuleHolder* ruleHolder)
		: ruleChecker_(ruleHolder)
	{}

	bool CheckProcess(wchar_t* nameToCheck,
					  size_t nameSize)
	{
		return ruleChecker_.CheckRules(
			boost::bind(&ProcessRuleChecker::CheckObjectName,this,
						nameToCheck,nameSize,_1));
	}
private:
	bool CheckObjectName(wchar_t* nameToCheck,
						 size_t nameSize,
						 const std::wstring& ruleObjName)
	{
		return utils::ApplyWildCards(ruleObjName.c_str(),
									 ruleObjName.size(),
									 nameToCheck,
									 nameSize);
	}

};
}