#include "KSynchroObject.h"

KSynchroObject::KSynchroObject()
{

}

KSynchroObject::~KSynchroObject()
{

}

