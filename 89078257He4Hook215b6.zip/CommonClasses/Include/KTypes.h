#ifndef __K_TYPES_H
 #define __K_TYPES_H

typedef unsigned char    BYTE, *PBYTE;
typedef unsigned short   WORD;
typedef unsigned long    DWORD;
typedef __int64          INT64_PTR, *PINT64_PTR;
typedef unsigned __int64 UINT64_PTR, *PUINT64_PTR;

#endif //__K_TYPES_H
